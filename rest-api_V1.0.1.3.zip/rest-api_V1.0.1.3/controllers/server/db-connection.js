    //Holds the user router defination

var express = require('express');
var router = express.Router();

var tenantsdb = require('../../middleware/tenantsdb_connection');

//Create User record in database
router.post('/connpool',function(req,res){
        var conn_status=[];
        tenantsdb.getTenantConnPool(function(connections_pool){
            connections_pool.forEach(function(conn) {
                conn_status.push({
                    tenant_id:conn.tenant_id,
                    connection_status:conn.status
                });
            }, this);
            res.status(200).send(conn_status);     
        });
});


module.exports = router;

