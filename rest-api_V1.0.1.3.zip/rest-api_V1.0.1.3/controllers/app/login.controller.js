//Holds the user authentication defination
var express = require('express');
var router = express.Router();

var masterdb = require('../../middleware/masterdb_connection');
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//        URL To be accessed :: http://<host>:<port>/auth/
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
User Authentication
Sample Authentication Input : 
Method : POST
input body = {
    "login_id":"AAS00001",
    "tenant_id":"AA",
    "password":"password",
    "status":"Active",
    "last_login":null
}
*/

/*     
  Authentication record creation
      */
router.post('/create',function(req,res){
      console.log('INFO :: Creating Login Record'); 
      console.log(req.body);
      //validation on data and preparing draft record
            draftRecord={ 
                    login_id:req.body.login_id,
                    tenant_id:req.body.tenant_id,
                    password:req.body.password,
                    status:'Active',
                    last_login:null
                  };
        masterdb.getMDBConn(function(status,db){
          if(status=='CONNECTED'){
            db.collection("login").insert(draftRecord,function(err, record) {
            if(err){
              res.send('Error :: While inserting data');
            }
            else{
            res.send(record);
            }
           });  
          }
        });
});
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////

router.post('/userlist',function(req,res){
      console.log('INFO :: User login list Fetching'); 
      query={};

      masterdb.getMDBConn(function(status,db){
          if(status=='CONNECTED'){
             //query data and sending response with received data
            db.collection("login").find(query,{"_id":false,"password":false}).toArray(function(err, users) {
            if(err){
              res.send('Error :: While fetching data');
            }
            else{
              if(!users){
                res.send({"Error":"User ID or password incorrecr"});
              }
              else
              {
                res.send(users);
              }
            }
          });   
          }
        })
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////
module.exports =router ;

