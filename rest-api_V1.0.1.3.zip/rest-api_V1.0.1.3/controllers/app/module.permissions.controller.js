//Holds the user authentication defination
var express = require('express');
var router = express.Router();

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//        URL To be accessed :: http://<host>:<port>/auth/
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*     
  Module Permission set getter on basis of roles
      */
router.post('/perms',function(req,res){

        //req.body.roles
       console.log('INFO :: Generating details for all students'); 
      
      //query data and sending response with received data
      req.db.collection("roles").find({role_name:{  $in :req.decoded.roles}},{_id:0,role_name:0}).toArray(function(err, modperms) {
            if(err){
              res.send('Error :: While fetching data'+err);
            }
            else{
              res.send(modperms);
            }
    });
});
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////////
module.exports =router ;

