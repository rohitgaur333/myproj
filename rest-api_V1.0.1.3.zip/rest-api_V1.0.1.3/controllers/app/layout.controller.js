//Holds the user authentication defination
var express = require('express');
var router = express.Router();

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//        URL To be accessed :: http://<host>:<port>/api/protected/layout/header
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*     
  Module Permission set getter on basis of roles
      */
router.post('/header',function(req,res){

      console.log('INFO :: Generating Header Data'); 
      var output={};
      //query data and sending response with received data
      req.db.collection("layout").find({role_name:{  $in :req.decoded.roles}},{_id:0,nav_menu:1}).toArray(function(err, nav_menu) {
            if(err){
                console.log("inside layout error");
              res.send('Error :: While fetching data'+err);
              output={
                error:err,
                nav_menu:null
              }
            }
            else{
                console.log("inside layout success");
                output.nav_menu={
                  error:null,
                  data:nav_menu[0].nav_menu}
                
            }
            req.db.collection("school_profile").find({},{_id:0}).toArray(function(err, profile) {
              if(err){
                  console.log("inside school profile error");
                output.school_detail={
                  error:err,
                  data:null
                }
              }
              else{
                  console.log("inside layout success");
                  output.school_detail={
                    error:null,
                    data:profile
                  }
                res.send(output);
              }
        });
    });
    
});
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////
router.post('/sidebar',function(req,res){

      console.log('INFO :: Generating Header Data'); 
      
      //query data and sending response with received data
      req.db.collection("layout").find({role_name:{  $in :req.decoded.roles}},{_id:0,sidebar_menu:1}).toArray(function(err, sidebar_menu) {
            if(err){
              res.send('Error :: While fetching data'+err);
            }
            else{
              res.send(sidebar_menu[0].sidebar_menu);
            }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////
module.exports =router ;
