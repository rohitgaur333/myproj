//Holds the student router defination
var express = require('express');
var router = express.Router();
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//        URL To be accessed :: http://<host>:<port>/student/<route>        
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Student Registration 
Sample Registration Input : 
Method : POST
input body = {
"fname":"Yogesh",
"mname": " ",
"lname": "Tiwari",
"dob": "01-Jul-86",
"gender": "M",
"class":"4",
"section":"A",
"contact_number":984656511,
"alternate_contact_number":9898387484,
"address":"Delhi",
"father_name":"MR Tiwari",
"father_mobile":98789546,
"mother_name":"Mrs Tiwari",
"mother_mobile":956464655,
"previous_school":"RYAN"
}
*/
router.post('/register',function(req,res){
      console.log('INFO :: Registaion Start'); 
      
      console.log(req.body);
      //validation on data and preparing draft record
            draftRecord={ 
                    UID:null,
                    type:'student',
                    fname:req.body.fname,
                    mname: req.body.mname,
                    lname: req.body.lname,
                    dob: new Date(req.body.dob),
                    gender:req.body.gender,
                    roles_history:[],
                    current_roles:[{role_name:'Student',assign_date:new Date(),comment:'New Student'}],
                    class:req.body.class,
                    section:req.body.section,
                    contact_number:req.body.contact_number,
                    alternate_contact_number:req.body.alternate_contact_number,
                    address:req.body.address,
                    father_name:req.body.father_name,
                    father_contact_number:req.body.father_mobile,
                    mother_name:req.body.mother_name,
                    mother_contact_number:req.body.mother_mobile,
                    previous_school:req.body.previous_school,
                  };

      //getting next sequence for SID generation
      req.db.eval("getSequenceUID('student')", function(error, UID) { 
      //res.send(SID);
        if(UID){
        //assign SID to the drafted record
        draftRecord.UID=UID;
        req.db.collection("user").insert(draftRecord,function(err, record) {
            if(err){
              res.send('Error :: While fetching data');
            }
            else{
            res.send(record);
            }
           });
        }
        else
        {
          res.send('Sequence does not exist');
        }
      });
  /*     
      */
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////
router.post('/modify',function(req,res){
      console.log('INFO :: Student Details Modify Start'); 
      
      console.log(req.body);
      //validation on data and preparing draft record
            draftRecord={ 
                    fname:req.body.fname,
                    mname: req.body.mname,
                    lname: req.body.lname,
                    dob: new Date(req.body.dob),
                    gender:req.body.gender,
                    class:req.body.class,
                    section:req.body.section,
                    contact_number:req.body.contact_number,
                    alternate_contact_number:req.body.alternate_contact_number,
                    address:req.body.address,
                    father_name:req.body.father_name,
                    father_mobile:req.body.father_mobile,
                    mother_name:req.body.mother_name,
                    mother_mobile:req.body.mother_mobile,
                    previous_school:req.body.previous_school,
                  };

        if(req.body.SID){
        req.db.collection("user").findAndModify({UID:req.body.UID},
                                                    [['_id','asc']], 
                                                    {$set:draftRecord},
                                                    {"remove":false,"new":true},
        function(err, record) {
            if(err){
              res.send('Error :: While fetching data');
              console.log("Error: "+err);
            }
            else{
              console.log(record);
            res.send(record.value);
            }
           });
        }
        else
        {
          res.send('Sequence does not exist');
        }
      });


//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
To fetch all students details
*/
router.get('/details',function(req,res){
      console.log('INFO :: Generating details for all students'); 
      
      //query data and sending response with received data
      req.db.collection("user").find({type:'student'}).toArray(function(err, students) {
            if(err){
              res.send('Error :: While fetching data');
            }
            else{
              res.send(students);
            }
    });   
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
  To fetch single student details
*/
router.get('/details/:UID',function(req,res){
       console.log('INFO :: Generating details for Student ID :'+ req.params.UID); 
      //query data and sending response with received data
         req.db.collection("user").findOne({UID:req.params.UID,type:'student'},function(err, student) {
            if(err){
              res.status(404).send({Error:'While fetching data'});
            }
            else{
            res.send(student);
            }
    });   
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////

//to get a specific user based on id search and customized fields
//sample query and filter
/*--------------------
{
	"query":{"SID":"S00023","fname":"yog"},
	"filter":{
			"SID":true,
			"fname":true,
			"lname":true
			}
}
*/
router.post('/customquery',function(req,res){
    console.log(req.body);
    let query={type:'student'};
    if(req.body.query.UID){
      query.UID={ $regex: req.body.query.UID, $options: 'i' };
      console.log("update UID");
    }
    if(req.body.query.fname){
      query.fname={ $regex: req.body.query.fname, $options: 'i' };
      console.log("update fname");
      };
    filter=req.body.filter;
    console.log(query);
    req.db.collection("user").find(query,filter).toArray(function(err, students) {
        console.log('inside custom method');
        if(err){
            console.log('500 + Error occurred while fetching the student record');
            return res.status(500).send("Error occurred while fetching the student record "+err);
        }
        if(!students){
            console.log('Not found');
            return res.status(404).send("User Not found");
        }
        console.log(students);
        res.status(200).send(students);
    });
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////
module.exports =router ;

