//Holds the user authentication defination
var express = require('express');
var router = express.Router();

// jwt used to create, sign, and verify tokens
var jwt    = require('jsonwebtoken');
var conf = require('../../config/conf');


var masterdb = require('../../middleware/masterdb_connection');
var user_profile = require('../../middleware/user_profile');

//////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Authentication operation: 
URL:<localhost:4000/api/public/authenticate
Sample Authentication Input : 
Method : POST
input body = {
    "login_id":"AAS00001",
    "password":"password",
    "status":"Active"
}

*/
router.post('',function(req,res){
      console.log('INFO :: User login start'); 
      query={
        login_id:req.body.login_id
      }
     //verify the request from the master database      
      masterdb.getMDBConn(function(status,db){
        /*
        check if status is database connection is connected
        */
          if(status=='CONNECTED'){
            /*
            query the login collection in masterdb and verify the user exist 
            also extract the record of user if found in database
            */
            db.collection("login").findOne(query,function(err, user) {
              /*
              Throw error is error occured while getting the user from database
              */
              if (err) throw err;
              /*
              Check if User not found with corresponding login_id in login collection of masterdatabase.
              */
              if (!user) {
                  res.status(400).json("Authentication failed. User not found.");
              }
              /*
                if user found validate the password and respond with JWT
              */
              else if (user) {
                // check if password matches
                if (user.password != req.body.password) {
                    res.status(400).json("Authentication failed. Wrong password.");
                } 
                else {
                    // if user is found and password is right
                    // create a token
                      user_profile.getProfile(user.UID,user.tenant_id,function(err,profile){
                        if(err){
                          console.log(err);
                          res.json('Error occured : '+err);    
                        }
                        else{
                        var token = jwt.sign({
                                          UID:user.UID,
                                          tenant_id:user.tenant_id,
                                          roles:profile.roles}, conf.secret);
                        
                      var result={};
                      result={
                      login_id: user.login_id,
                      tenant_id: user.tenant_id,
                      UID:user.UID,
                      token: token,
                      user_name:profile.user_name,
                      roles:profile.roles
                    }
                        res.json(result);
                        }
                      });
                }   
            }  
          });   
          }
        })
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////
module.exports =router ;

