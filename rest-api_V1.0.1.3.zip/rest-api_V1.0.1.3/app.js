var express = require('express');
var bodyParser = require('body-parser');
var morgan      = require('morgan');
var app = express();
var cors = require('cors');



//require the mongodb connection from config file specified in config/mdb.js
var mdb_conf = require('./config/mdb');

//body parser Middleware
app.use(bodyParser.urlencoded({ extended : true}));
app.use(bodyParser.json());

// use morgan to log requests to the console
app.use(morgan('dev'));
app.use(cors());


//to allow connection from cross origin i.e different IP address and port combination
var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type,x-access-token, Access-Control-Request-Method, Access-Control-Request-Headers");
    //res.header('Access-Control-Allow-Headers', 'Content-Type');
    //res.header('Access-Control-Allow-Headers', 'x-access-token');
    next();
}
app.use(allowCrossDomain);

/////////////////////////////////////////////////////////////////////////////////////////
//      Initializing master database connections and storing in connection pool        //
/////////////////////////////////////////////////////////////////////////////////////////
var masterdb = require('./middleware/masterdb_connection');
var tenantsdb = require('./middleware/tenantsdb_connection');
masterdb.connect(mdb_conf.database_url,function(status,masterdb_conn){
    app.set("MDB_Conn",masterdb_conn);
    console.log("INFO :: Master DB Connection Status : "+status);
    if(status=='CONNECTED'){
        ///initializing tenants databases connections and storing in connection pool
        tenantsdb.initTenantsDB(masterdb_conn,function(executed){
            if(executed){
                tenantsdb.getTenantConnPool(function(pool){
                    console.log('INFO :: Middleware code executed successfully');
                    //console.log(pool);
                });
            }
            
        })
    }
});
/////////////////////////////////////////////////////////////////////////////////////////

//Auth controller
var authController= require('./controllers/core/auth.controller');
app.use('/api/public/authenticate',authController);

app.use(function (req, res, next) {
    console.log("checking request");
    console.log(req.body);
    next();
});

/////////////////////////////////////////////////////////
///// Middleware to protected routes and verify JWT   ///
/////////////////////////////////////////////////////////
var apiRoutes = express.Router(); 
var routeProtector = require('./middleware/route_protector');
apiRoutes.use(routeProtector.shield);
app.use('/api/protected', apiRoutes);

/*
      Note : This middleware opens jwt and grep tenent_id, UID and roles and assign it to 
      Object in following format
      req.decoded= {    UID: 'S00009',
                        tenant_id: 'AA',
                        roles: [ { role_name: 'Student' } ],
                        iat: 1506403437 }
    */

/////////////////////////////////////////////////////////

app.use(function (req, res, next) {
    console.log('INFO :: Tenant Selection Middleare');
    console.log(req.body);
    
    console.log(req.decoded);

    if(req.decoded.tenant_id){
//if(true){
  //  tenant_id='AA';
    tenant_id=req.decoded.tenant_id;
    tenantsdb.getTenantConnection(tenant_id,function(conn){
        if(conn){
        console.log('INFO :: Connection Selected for Tenant ID : '+tenant_id);
        console.log('abc');
        req.db = conn;
        next();
        }
    else{
        console.log("WARNING :: Tenant ID :"+tenant_id+" is not available !!!");
        res.send("WARNING :: Tenant ID :"+tenant_id+" is not available !!!");
    }
    });
    }
    else{
        next();
    }
});


//application loading after authentication
//Module permission getter
var moduleController= require('./controllers/app/module.permissions.controller');
app.use('/api/protected/module',moduleController);

////////////////////////////////////////////////////////////////////


//layout controller
var layoutController= require('./controllers/app/layout.controller');
app.use('/api/protected/layout',layoutController);
////////////////////////////////////////////////////////////////////

//Login controller
var loginController= require('./controllers/app/login.controller');
app.use('/api/protected/login',loginController);

//server controller definations 
var serverController=require('./controllers/server/db-connection');
app.use('/api/protected/server',serverController);

//bind controller to application with root 
//tenant controller defincations
var studentController = require('./controllers/app/student.controller');
app.use('/api/protected/student',studentController);


module.exports = app;