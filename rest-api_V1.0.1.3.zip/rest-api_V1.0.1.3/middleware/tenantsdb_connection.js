var MongoClient = require( 'mongodb' ).MongoClient;

var tenantsConnPool = [];
/*interface for tenantsConnPool
                    tenant_id:'AA',
                    status:'Connected',
                    conn:'connection definations
*/

module.exports = {
 getTenantConnPool : function (callback){
    callback(tenantsConnPool);
},
getTenantConnection : function (tenant_id,callback){
    var connection=null;
    tenantsConnPool.forEach(function(tenant){
        if(tenant.tenant_id==tenant_id){
        //console.log(tenant);
        connection=tenant.conn;
        callback(connection);
    }
})


    },
initTenantsDB: function(masterdb_conn,callback){
    if(masterdb_conn){
        console.log('INFO :: Getting Tenants Details !!! ');
        var collection = masterdb_conn.collection('tenants');
        collection.find().toArray(function(err, tenants) {
        if(tenants.length>0){
        tenants.forEach(function(tenant_params) {
           // console.log(tenant_params);
            module.exports.connectTenantDB(tenant_params,function(err,status){
                if(err){
                    console.log("INFO :: Tenant Database : "+tenant_params.tenant_id+" Connection Failed with error : "+err);
                }
                else{
                    console.log("INFO :: Tenant Database : "+tenant_params.tenant_id+" Connection Successful");
                }
                /*
                end of array for each so that we can execute the callback after it finisehes.
                */
            if(tenants.length == tenantsConnPool.length){
                console.log('INFO :: Init all tenant connection processed');
                callback(true);
            }
            });          
         }
        );
        }
        else{
        console.log('WARNING :: No Tenant Exist !!!');
        }
       }
);  
}
},
/*
connection params need to be entered at the time of making tenant connection
conn_params = {
    tenant_id:'AA'
    url:var masterdb_url="mongodb://127.0.0.1:27017/masterdb",
    admin:'Admin',
    password:'password,
}*/
connectTenantDB: function(conn_params,callback){
    if(conn_params){
    MongoClient.connect( conn_params.url , function( err, tenantdb_conn ) {
      if(err)
      {
        tenantsConnPool.push({
                    tenant_id:conn_params.tenant_id,
                    status:err,
                    conn:undefined
                });
        callback(err,null);
      }
      else{
        tenantsConnPool.push({
            tenant_id:conn_params.tenant_id,
            status:'Connected',
            conn:tenantdb_conn
        });
        callback(null,tenantdb_conn);
      }
    });
    }
 }
};