var MongoClient = require( 'mongodb' ).MongoClient;

var state = {
    db : undefined,
    status : undefined
}

module.exports = {

//function to connect to master db
  connect : function(masterdb_url,callback) {
    MongoClient.connect( masterdb_url , function( err, db_conn ) {
      if(err)
      {
        //console.log('Error occured while connecting to masterdb');
        state.db=undefined;
        state.status='Error : '+err;
      }
      else{
        state.db=db_conn;
        state.status='CONNECTED';
        //console.log('masterdb connected successfully');
      }
      callback(state.status,state.db);
    });
  },

 getMDBConn: function(callback) {
     callback(state.status,state.db);
  },

 getStatus: function(callback){
   callback(state.status);
   var collection = state.db.collection('tenants');
  collection.find().toArray(function(err, items) {
         console.log(items);
       });
}
}
