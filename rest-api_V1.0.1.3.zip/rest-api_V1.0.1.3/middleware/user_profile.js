var tenantdb = require('./tenantsdb_connection');

////////////////////////////////////////////////////////////////////////
///         Middleware method to get roles and module permissions     ////
////////////////////////////////////////////////////////////////////////
module.exports ={
    getProfile: function(UID,tenant_id,callback) {
    console.log('UID : '+UID + " Tenant_ID : "+tenant_id)
    tenantdb.getTenantConnection(tenant_id,function(db_conn){
        if(db_conn){
            db_conn.collection("user").findOne({UID:UID},{"_id":0,"current_roles.role_name":1,fname:1,lname:1},function(err, profile) {
                console.log("sending profile");
                console.log(profile);

                /*
                Convert roles to flat string map 
                From : { current_roles: [ { role_name: 'Student' } ] }
                To: ["Student"]
                */
                var roleToSend=[];
                if(profile.current_roles.length>0){
                profile.current_roles.forEach(role=>{
                    roleToSend.push(role.role_name)
                });
                }
                var output={
                    user_name:profile.fname+" "+profile.lname,
                    roles:roleToSend
                }
                callback(null,output);
            });
        }
        else{
            console.log("connection not found");
            callback(err,null);
        }
    });
}
}

