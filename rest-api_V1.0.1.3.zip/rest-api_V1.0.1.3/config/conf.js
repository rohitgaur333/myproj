module.exports = {
    'secret': 'secretkey'
};