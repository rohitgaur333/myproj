import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';
 
//Necessary import for NGRX Store implemenation
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

//Reducers defination import
import { header_reducer } from './state/reducers/header.reducer';
import { sidebar_reducer } from './state/reducers/sidebar.reducer';
import { student_reducer} from './state/reducers/student.reducer';
import { APP_REDUCERS} from './state/reducers/app.reducers';

//Bootstrap component for application loading 
import { AppComponent } from './app.component';

//Modules import and subsequent declaration for module access through out application
import { HeaderModule } from './modules/header/header.module';
import { SidebarModule } from './modules/sidebar/sidebar.module';
import { StudentModule } from './modules/student/student.module';


//Common module having common component such as error pages and information messages component
import { CommonModule } from './modules/common/common.module';

//Root Routing Module for applicaion router which holds all the child router definations for application routes
import { AppRootRoutes } from './app.routing';

@NgModule({
  declarations: [
    //Bootstrap and Custom Component Declaration 
    AppComponent,
        ],
  imports: [
    //OOTB Module Import
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule,
    //Iitialize the ngrx store provided with the application combined reducer(reducer holding all the separate reducers)
    StoreModule.provideStore(APP_REDUCERS),

    //To enable devtools extension for debugging via Chrome/Mozilla browser Note : Install extension for debugging Redux implementation
    StoreDevtoolsModule.instrumentOnlyWithExtension(),

    //Application Specific Custom Modules(Holding Custom Component)declaration
    AppRootRoutes,
    HeaderModule,
    SidebarModule,
    CommonModule,
    StudentModule
  ],
  exports:[RouterModule],
  bootstrap: [AppComponent],
})
export class AppModule { }