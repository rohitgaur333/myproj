import { Injectable} from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable,Subject,Subscription } from 'rxjs';
import { AppState} from '../interfaces/appstate.interface';
import { RegisterStudent,SearchStudentList,SearchStudentResult,SelectedStudent,StudentInterface} from '../interfaces/student.interface';

@Injectable()
export class StudentDataService{

    // Observable sources
    private selectedStudent=new Subject<SelectedStudent>();
    private subscription;
    private sub;

    // Observable streams
    selectedStudent$=this.selectedStudent.asObservable();

    constructor(private _store:Store<AppState>){
        console.log('inside data service const');
        this.subscription=this._store.select<StudentInterface>('student_data');
        }

        getSelectedStudent(){
            this.subscription.subscribe(studentRecord=>{
            this.selectedStudent.next(studentRecord.selectedStudent);
            this.sub=Observable.interval(1000).take(20).subscribe(data=>{
                console.log(data);
            })
        })
    
        }

        ngOnDestroy(){
            console.log('data service endds');
            this.sub.unsubscribe();
            
        }

}