export interface HeaderInterface {
 school_detail:Header_School_Details,
 nav_menu:Header_Menu_Item[],
 account_menu: Header_Account_Details
}

export interface Header_Menu_Item {
    link_name:string,
    link_url:string,
        
}
export interface Header_Account_Details {
    account_id:string
}

export interface Header_School_Details {
    name:string,
    short_name:string
}