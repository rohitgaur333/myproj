import { HeaderInterface } from './header.interface';
import { SidebarInterface } from './sidebar.interface';
import { StudentInterface } from './student.interface';

export interface AppState {
    headerData:HeaderInterface,
    sidebarData:SidebarInterface,
    studentData:StudentInterface
}