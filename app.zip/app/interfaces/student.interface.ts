export interface StudentInterface{
	selectedStudent:SelectedStudent,
	student_list:StudentList,
	searchStudent_list:SearchStudentList,
	registerStudent:RegisterStudent
}
export interface StudentList{
	studentList:Student[],
	loading:boolean
}
export interface RegisterStudent{
	draftRecord:Student,
	loading:boolean
}

export interface SelectedStudent{
	studentRecord:Student,
	loading:boolean
}
export interface SearchStudentList{
	searchStudentList:SearchStudentResult[],
	loading:boolean
}
export interface SearchStudentResult{
	fname: string;
	lname: string;
	dob:string;
}

export interface Student{
    fname: string;
    mname?: string;
	lname: string;
	gender: string;
	dob:string;
	class?:string;
	section?:string;
	student_mobile:number;
	father_name:string;
	father_mobile:number;
}