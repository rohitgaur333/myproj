import { Component,Input,Output,ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { IMyDpOptions,IMyDate} from 'mydatepicker';
import { StudentDataService } from '../../../services/student-data.service';

@Component({
 moduleId: module.id,
  selector: 'student-details',
  templateUrl:'./student-details.component.html',
  styleUrls:['./student-details.component.css'],
  providers:[StudentDataService],
  
})
export class StudentDetailComponent  { 
   
    //variable declaration
    loading:boolean=false;
    studentDetailForm:FormGroup;
    dateForm: FormGroup;
    private selDate: IMyDate = {year: 0, month: 0, day: 0};

    data:any;

    //datepicker options eg format of the date
    private myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd-mm-yyyy',
    };

    @Input() d_selectedStudent;

    constructor(private formBuilder: FormBuilder,private studentDataService:StudentDataService){
      let d: Date = new Date();
        this.selDate = {year: d.getFullYear(), 
                        month: d.getMonth() + 1, 
                        day: d.getDate()};
                  console.log(this.selDate);
    
      console.log('inside details const');
      this.studentDataService.selectedStudent$.subscribe(data=>{
        console.log("inside details");
        console.log(data);
        this.data=data;
      });
      
    }
    
    
  ngOnInit() {
    this.studentDetailForm = this.formBuilder.group({
    fname:['',Validators.required],
    mname: '',
    lname:['',Validators.required],
    dob:['',Validators.required],
    gender:['',Validators.required],
    class:[''],
    section:[''],
    student_mobile:['',Validators.required],
    father_name:['',Validators.required],
    father_mobile:['',Validators.required]
  });
  this.studentDataService.getSelectedStudent();
  this.studentDetailForm.patchValue(this.data.studentRecord);
  this.selDate=this.data.studentRecord.dob;
//  this.registerForm.valueChanges.subscribe()
  }

setDate(dateValue){
 this.studentDetailForm.controls['dob'].setValue(dateValue);
 this.studentDetailForm.controls['dob'].markAsTouched();
}

saveStudentDetail(studentRecord){
    console.log(studentRecord);
    this.loading=true;
}  
editStudentRecord(){}

ngOnDestroy(){
  
}
}
