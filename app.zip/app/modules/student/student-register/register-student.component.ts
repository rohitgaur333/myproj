import { Component,Input,OnInit,ViewChild,ElementRef  } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { IMyDpOptions} from 'mydatepicker';

@Component({
 moduleId: module.id,
  selector: 'student-register',
  templateUrl:'./register-student.component.html',
  styleUrls:['./register-student.component.css'],
  providers:[],
})
export class RegisterStudentComponent implements OnInit  { 

constructor(private formBuilder: FormBuilder) {}

    registerForm:FormGroup;
    dateForm: FormGroup;
    //datepicker options eg format of the date
    private myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd-mm-yyyy',
    };
    
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
    fname:['',Validators.required],
    mname: '',
    lname:['',Validators.required],
    dob:['',Validators.required],
    gender:['',Validators.required],
    class:[''],
    section:[''],
    student_mobile:['',Validators.required],
    father_name:['',Validators.required],
    father_mobile:['',Validators.required]
  });
 
//  this.registerForm.valueChanges.subscribe()
  }

setDate(dateValue){
 this.registerForm.controls['dob'].setValue(dateValue);
 this.registerForm.controls['dob'].markAsTouched();
}

  registerStudent(studentRecord){
    console.log(studentRecord);
  }  
}
