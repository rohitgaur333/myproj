import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AppState } from '../../interfaces/appstate.interface';
import { StudentInterface, SelectedStudent } from '../../interfaces/student.interface';

@Component({

    selector:'student-container',
    templateUrl:'./student.container.html',
    styleUrls:['./student.container.css']
})

export class StudentContainer  {

    //variable declaration
    s_selectedStudent: SelectedStudent;

    constructor(private router:Router,private _store:Store<AppState>)
        {
        this._store.select<StudentInterface>('student_data').subscribe(student_data=>{
        this.s_selectedStudent=student_data.selectedStudent;
    })
}


ngOnInit() {

    }

}