import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { StudentContainer } from './student.container';
import { RegisterStudentComponent } from './student-register/register-student.component';
import { StudentDetailComponent } from './student-details/student-details.component';
import { PageNotFoundComponent } from '../../modules/common/not-found.component';
import { DummyComponent } from '../../modules/common/dummy.component';

const routes: Routes =[
   { path:'student',component:StudentContainer,
        children: [
                    { path: '', redirectTo: 'index', pathMatch: 'full' },
                    { path: 'index', component: PageNotFoundComponent },
                    { path: 'dummy', component: DummyComponent  },
                    { path: 'details', component: StudentDetailComponent },
                    { path: 'register', component: RegisterStudentComponent  },
                    { path: 'details/:id', component: StudentDetailComponent  }
         ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class StudentRoutingModule {

}