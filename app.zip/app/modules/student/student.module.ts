import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule} from '@angular/router';
import { DatePickerModule } from 'ng2-datepicker';

import { StudentContainer }   from './student.container';

import { RegisterStudentComponent } from './student-register/register-student.component';
import { StudentDetailComponent } from './student-details/student-details.component';
import { StudentRoutingModule } from './student.routing';

import { DatePicker } from '../common/date-picker.component';
import { MyDatePickerModule } from 'mydatepicker';

import {BusyModule} from 'angular2-busy';


@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule,
    StudentRoutingModule,
    DatePickerModule,
    MyDatePickerModule,
    BusyModule
  ],
  declarations: [
    RegisterStudentComponent,
    StudentContainer,
    StudentDetailComponent,
    DatePicker
    ],
  exports: [ StudentContainer]
})

export class StudentModule { }