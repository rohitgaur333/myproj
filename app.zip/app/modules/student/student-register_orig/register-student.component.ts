import { Component,Input,ViewChild,ElementRef } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
//import { UserService } from '../../../services/user/user.service';
import {FormsModule, ReactiveFormsModule, FormBuilder , Validators, FormGroup,FormControl} from '@angular/forms';
//import { ValidationService } from '../../../services/validation.service';
import { DatePicker } from '../../common/date-picker.component';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';

@Component({
 moduleId: module.id,
  selector: 'register-student',
  templateUrl:'./register-student.component.html',
  styleUrls:['./register-student.component.css'],
  providers:[],
})
export class RegisterStudentComponent  { 
 
 date:DateModel;
 
 //dob=this.date.formatted;
  options: DatePickerOptions ={
        
  };

    constructor(private formBuilder: FormBuilder,private route: Router){
        this.options = new DatePickerOptions();
    }
 
    fname= new FormControl('', [Validators.required]);
    mname= new FormControl('');
    lname= new FormControl('', [Validators.required]);
    dob= new FormControl('', [Validators.required]);
    //dob=this.date ? this.date.formatted : '';
    gender= new FormControl('', [Validators.required]);
    class= new FormControl('');
    section= new FormControl('');
    student_mobile= new FormControl('');
    father_name= new FormControl('', [Validators.required]);
    father_mobile= new FormControl('');
    
  registerForm: FormGroup = this.formBuilder.group({
    fname: this.fname,
    mname: this.mname,
    lname: this.lname,
    dob:this.dob,
    gender:this.gender,
    class:this.class,
    section:this.section,
    student_mobile:this.student_mobile,
    father_name:this.father_name,
    father_mobile:this.father_mobile,
    date:this.date
});



registerStudent () {
    console.log(this.registerForm.value);
  }
  getvalue(){
      
  }

dateValue : any;
    ngOnInit(){
             
    }
    

ngOnDestroy(){
    //this.sub.unsubscribe();
}
}
