import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//import { HeaderComponent }   from './header.component';
import { LogoTitleComponent } from './logo-title/logo-title.component';
import { ToggleSidebarComponent } from './toggle-sidebar/toggle-sidebar.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

//Header Container Import holding all the Components and related Services
import { HeaderContainer } from './header.container';


@NgModule({
  imports:      [
    CommonModule,
 //   FormsModule,
  //  HttpModule,
  ],
  declarations: [
    HeaderContainer,
  //  HeaderComponent,
    LogoTitleComponent,
    ToggleSidebarComponent,
    NavMenuComponent,
    UserProfileComponent
    ],
  exports: [ 
     HeaderContainer
  ]
})

export class HeaderModule { }