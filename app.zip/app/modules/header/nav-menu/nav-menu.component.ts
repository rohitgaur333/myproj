import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'header-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent implements OnInit {

  @Input() nav_menu;
  @Output() navigateClick : EventEmitter<string>=new EventEmitter();
  constructor() { 
    
  }

  ngOnInit() {
  }

}
