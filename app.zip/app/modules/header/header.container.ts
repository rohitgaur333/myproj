import { Component,Input } from '@angular/core';
import { Router, RouterLink,ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { Store } from '@ngrx/store';
import { AppState } from '../../interfaces/appstate.interface';
import { Header_Account_Details, HeaderInterface,Header_Menu_Item,Header_School_Details } from '../../interfaces/header.interface';

@Component({
  selector: 'header-container',
  template:`
            <header class="main-header">
              <header-logo-title [school_detail]="school_detail_data" ></header-logo-title>
                 <!-- Header Navbar -->
                     <nav class="navbar navbar-static-top" role="navigation">
                          <header-toggle-sidebar></header-toggle-sidebar>
                              <!-- Navbar Right Menu -->
                              <div class="navbar-custom-menu">
                                <header-nav-menu 
                                class="nav navbar-nav"
                                [nav_menu]="nav_menu_data"
                                (navigateClick)="navigateUrl($event)"
                                ></header-nav-menu>
                                <header-user-profile class="nav navbar-nav"
                                [account_menu]="account_menu_data"
                                ></header-user-profile>
                              </div>
                      </nav>
              </header>
            `,
})

export class HeaderContainer {

  school_detail_data:Observable<Header_Account_Details>;
  nav_menu_data:Observable<Header_Menu_Item[]>;
  account_menu_data:Observable<Header_Account_Details>;
  
  constructor(private _store:Store<AppState>,private route:Router){
      this._store.select('header_data').subscribe(headerData=>{
        this.school_detail_data=headerData['school_detail'];
        this.nav_menu_data=headerData['nav_menu'];
        this.account_menu_data=headerData['account_menu'];
      });
   }

   navigateUrl(url: string){
    this.route.navigateByUrl(url);
   }


}
