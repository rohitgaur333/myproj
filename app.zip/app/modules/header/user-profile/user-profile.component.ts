import { Component, OnInit, Input } from '@angular/core';
import { Header_Account_Details } from '../../../interfaces/header.interface';

@Component({
  selector: 'header-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

@Input() account_menu:Header_Account_Details;

  constructor() { }

  ngOnInit() {
  }

}
