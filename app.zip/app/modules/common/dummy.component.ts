import { Component } from '@angular/core';
@Component({

    selector:'dummy-details',
    template:`<p>Dummy</p>
               
                `,
    
})

export class DummyComponent  {
}