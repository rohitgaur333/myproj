import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';

import { SidebarContainer }   from './sidebar.container';
import { Routes, RouterModule } from '@angular/router';
import { SidebarMenuComponent } from './sidebar-menu/sidebar-menu.component';



@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  declarations: [
    SidebarContainer,
    SidebarMenuComponent
    ],
  exports: [ 
     SidebarContainer
  ]
})

export class SidebarModule { }