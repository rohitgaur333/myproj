import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Sidebar_Item } from '../../interfaces/sidebar.interface';
import { AppState } from '../../interfaces/appstate.interface';
import { Observable } from 'rxjs';



@Component({
  selector: 'sidebar-container',
  templateUrl: './sidebar.container.html',
  styleUrls: ['./sidebar.container.css'],
})
export class SidebarContainer {

   sidebar_menu_data:Observable<Sidebar_Item[]>;

  constructor(private _store:Store<AppState>){
      this._store.select('sidebar_data').subscribe(
        state_sidebar_data=>{
        this.sidebar_menu_data=state_sidebar_data['item_list'];
        }
      );
  }
}
