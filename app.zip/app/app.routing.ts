import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


import { PageNotFoundComponent } from './modules/common/not-found.component';
import { DummyComponent } from './modules/common/dummy.component';

const appRoutes: Routes = [
  //Setting Root Routes for application routing eg "StudentContainer" or default:"PageNotFoundComponent""    
   {path: 'dummy', component: DummyComponent },
   {path: '**', component: PageNotFoundComponent },
   
 
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const AppRootRoutes: ModuleWithProviders = RouterModule.forRoot(appRoutes);

