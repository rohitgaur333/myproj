import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Actions,Effect } from '@ngrx/effects';
import { StudentService } from '../../services/student.service';
import { GET_STUDENT,GET_STUDENT_ERROR,GET_STUDENT_SUCCESS} from '../actions/student.actions';

@Injectable()
export class StudentEffects {
    constructor(private studentService:StudentService,private action$:Actions){
    }
@Effect() getStudent$ = this.action$
    .ofType(GET_STUDENT)
    .switchMap(action=>
        this.studentService.getStudent()
            .map(receivedRecord=>({type:GET_STUDENT_SUCCESS,payload:receivedRecord}))
            .catch(()=>Observable.of({type:GET_STUDENT_ERROR})));
}