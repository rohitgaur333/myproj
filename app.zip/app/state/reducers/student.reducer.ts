import { Action, ActionReducer} from '@ngrx/store';
import { StudentInterface} from '../../interfaces/student.interface';

const initialState:StudentInterface={
    selectedStudent : { studentRecord: {fname: "Rohit",
                                        mname:'',
                                        lname: "Gaur",
                                        gender: "Male",
                                        dob:"21-06-1990",
                                        class:"3",
                                        section:"B",
                                        student_mobile:9811536239,
                                        father_name:"Mr R A Gaur",
                                        father_mobile:9811536239},
                        loading:false},
    student_list:{studentList:[],
                    loading:false
                  },
    searchStudent_list:{searchStudentList:[],loading:false},
    registerStudent:{draftRecord:{
                                fname: undefined,
                                mname: undefined,
                                lname: undefined,
                                gender: undefined,
                                dob:undefined,
                                class:undefined,
                                section:undefined,
                                student_mobile:undefined,
                                father_name:undefined,
                                father_mobile:undefined
                            },loading:false}   
}

export function student_reducer  (state=initialState,action:Action):StudentInterface{
    switch (action.type){
        case 'GET_STUDENT':
        return state;

        default:
        return state;

    }
};

