import { Action, ActionReducer} from '@ngrx/store';
import { SidebarInterface} from '../../interfaces/sidebar.interface';


const initialState:any={
    item_list : [
              {name:"Dashboard",type:"heading",link:"dummy",icon_class:"fa fa-dashboard",sub_items:[]},
              {name:"Student",type:"treeview",link:"dummy",icon_class:"fa fa-child",
                sub_items:[
                    {name:"Registration",link:"student/register",icon_class:"fa fa-user-plus"},
                    {name:"Manage Student",link:"student/details",icon_class:"fa fa-edit"},
                    {name:"Attendance",link:"student/attendance",icon_class:"fa fa-edit"}
                    ]},
              {name:"Staff",type:"heading",link:"staff",icon_class:"fa fa-group",sub_items:[]},
              {name:"Payment",type:"heading",link:"payment",icon_class:"fa fa-money",sub_items:[]},
              {name:"Help",type:"heading",link:"help",icon_class:"fa fa-link",sub_items:[]},
                ]
  };



export function sidebar_reducer(state=initialState,action:Action){
    switch (action.type){
        case 'Sidebar_CLICK':
        return state;

        default:
        return state;

    }
};

