import { Action, ActionReducer} from '@ngrx/store';
import { HeaderInterface} from '../../interfaces/header.interface';

const initialState:HeaderInterface={
school_detail:{name:"Valley full",short_name:"VFS"},
nav_menu:[
      {link_name:"Dashboard",link_url:"dummy"},
      {link_name:"Settings",link_url:"/"},
      {link_name:"Profile",link_url:"/"},
      {link_name:"Help  ",link_url:"/"},
      {link_name:"student"  ,link_url:"student"}
    ],
    account_menu:
     {account_id:"S-acbec098"}
}

export function header_reducer(state=initialState,action:Action){
    switch (action.type){
        case 'NAV_CLICK':
        return state;

        default:
        return state;

    }
};

