import { student_reducer } from './student.reducer';
import { header_reducer } from './header.reducer';
import { sidebar_reducer} from './sidebar.reducer';

export const  APP_REDUCERS ={
    header_data:header_reducer,
    sidebar_data:sidebar_reducer,
    student_data:student_reducer};
