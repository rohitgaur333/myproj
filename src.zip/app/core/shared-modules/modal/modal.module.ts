import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModalComponent } from './components/modal.component';

@NgModule ({
    declarations:[
        ModalComponent        
     ],
    imports:[
            CommonModule,
            // routing definations for info routing
            ],
    exports:[ ModalComponent ]
})


export class ModalModule {}