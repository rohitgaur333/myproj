import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { RouterModule } from '@angular/router';

//ngrx module imports
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
//reducer definations import
import { reducer } from './reducers/';

//components import
import { SidebarContainer }   from './container/sidebar.container';
import { SidebarMenuComponent } from './components/sidebar-menu/sidebar-menu.component';
//effects and services import 
import { SidebarEffects } from './effects/sidebar.effects';
import { SidebarService } from './services/sidebar.service';

@NgModule({
  imports:      [
    CommonModule,
    RouterModule,
    StoreModule.forFeature('st_sidebar',reducer),
    EffectsModule.forFeature([SidebarEffects]),
  ],
  declarations: [
    SidebarContainer,
    SidebarMenuComponent
    ],
  exports: [ 
     SidebarContainer
  ],
  providers:[SidebarService]
})

export class SidebarModule { }