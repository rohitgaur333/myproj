import { Action } from '@ngrx/store';
import * as sidebarModel from '../model/sidebar.model';

//Action Type constants declarations
export const GET_SIDEBAR='[SIDEBAR] GET_SIDEBAR';
export const GET_SIDEBAR_SUCCESS='[SIDEBAR] GET_SIDEBAR_SUCCESS';
export const GET_SIDEBAR_ERROR='[SIDEBAR] GET_SIDEBAR_ERROR';



//interface of action
export class Interface implements Action {
  readonly type :string;
  public payload?:any;
}
//Action classes implementation

export class GetSidebarAction implements Action {
  readonly type = GET_SIDEBAR;
  constructor() {}
}

export class GetSidebarSuccessAction implements Action {
  readonly type = GET_SIDEBAR_SUCCESS;
  constructor(public payload:sidebarModel.SidebarModel) {}
}

export class GetSidebarErrorAction implements Action {
  readonly type = GET_SIDEBAR_ERROR;
  constructor(public payload:string) {}
}

