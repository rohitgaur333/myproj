export interface SidebarModel {
    item_list:Sidebar_Item[]
}

export interface Sidebar_Item{
    name:string,
    type:string,
    link:string,
    icon_class:string,
    sub_items: Sidebar_Sub_Item[]
}

export interface Sidebar_Sub_Item{
    name:string,
    link:string,
    icon_class:string,

}