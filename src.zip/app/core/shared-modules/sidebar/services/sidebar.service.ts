import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import { AuthService } from '../../../../root/auth-guard/auth.service';

@Injectable()
export class SidebarService {
  
    //temp_query;
    constructor(private http: Http,private authService: AuthService){
        console.log('Search Service Initiated...');
        
    }
        getSidebarMenu(){
        // return this.http.get('http://localhost:4000/student/'+studentRecord)
        // .map(res => res.json());
         console.log('Http Service Call');
        //let headers = new Headers ({ 'Content-Type': 'application/json' });
        //let headersObj = new Headers();
        let headers = new Headers ({ 'Content-Type': 'application/json' });
        console.log(this.authService.getToken());
        headers.append('x-access-token', this.authService.getToken());
        let options: RequestOptions = new RequestOptions({ headers: headers });
    	var body = JSON.stringify({});
    	console.log(body);
        return this.http.post('http://localhost:4000/api/protected/layout/sidebar', body ,options)
        .map(res =>res.json()) ;
    }
}