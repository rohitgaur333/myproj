import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Actions,Effect,toPayload  } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { SidebarService } from '../services/sidebar.service';
import * as sidebarAction from '../actions/sidebar.actions';



@Injectable()
export class SidebarEffects {

@Effect()
getSidebarMenu$ :Observable<Action> = this.action$
    .ofType(sidebarAction.GET_SIDEBAR)
    //.map(toPayload)
    .switchMap(()=>
          this.sidebarService.getSidebarMenu()
            .map(receivedRecord=>(new sidebarAction.GetSidebarSuccessAction(receivedRecord)))
            .catch((error)=>Observable.of(new sidebarAction.GetSidebarErrorAction(error))));

    constructor(private sidebarService:SidebarService,private action$:Actions){
    }
}


