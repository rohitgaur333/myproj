import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import * as sidebarModel from '../model/sidebar.model';
import * as sidebarActions from '../actions/sidebar.actions';
import * as fromSidebar from '../reducers';

import { RouterLink } from '@angular/router';

@Component({
  selector: 'sidebar-container',
  templateUrl: './sidebar.container.html',
  styleUrls: ['./sidebar.container.css'],
})
export class SidebarContainer {

   c_sidebar_menu_list:Observable<sidebarModel.Sidebar_Item[]>;

  constructor(private _store:Store<fromSidebar.State>){

    this._store.dispatch(new sidebarActions.GetSidebarAction());

     this.c_sidebar_menu_list=this._store.select(fromSidebar.getSidebarItemList);
  }
}
