import { Action, ActionReducer} from '@ngrx/store';
import * as sidebarModel from '../model/sidebar.model';
import * as sidebarActions from '../actions/sidebar.actions';

export interface State {
	item_list:sidebarModel.Sidebar_Item[],
	is_loading:boolean
}

const initialState:State={
    item_list : [
              {name:"Dashboard",type:"heading",link:"dummy",icon_class:"fa fa-dashboard",sub_items:[]},
              {name:"Student",type:"treeview",link:"./",icon_class:"fa fa-child",
                sub_items:[ 
                    {name:"Registration",link:"manage/student/register",icon_class:"fa fa-user-plus"},
                    {name:"Manage Student",link:"manage/student/details",icon_class:"fa fa-edit"},
                    {name:"Attendance",link:"manage/student/attendance",icon_class:"fa fa-edit"}
                    ]},
              {name:"Staff",type:"heading",link:"student/details/597b605d145c0a8e6a0c5511",icon_class:"fa fa-group",sub_items:[]},
              {name:"Payment",type:"heading",link:"student/details/597b605d145c0a8e6a0c550d",icon_class:"fa fa-money",sub_items:[]},
              {name:"Search",type:"heading",link:"student/search",icon_class:"fa fa-link",sub_items:[]},
                ],
    is_loading:false
  };

export function reducer(state=initialState,action:sidebarActions.Interface){
    switch (action.type){
        case sidebarActions.GET_SIDEBAR:
        return Object.assign({},state,{is_loading:true});

        case sidebarActions.GET_SIDEBAR_SUCCESS:
        return Object.assign({},state,{item_list:action.payload});

        default:
        return state;

    }
};

export const getSidebarItemList = (state:State) => state.item_list;

