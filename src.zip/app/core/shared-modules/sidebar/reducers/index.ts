import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromSidebar from './sidebar.reducer';

import * as fromRoot from '../../../../root/root-reducers/';

export interface State extends fromRoot.State{
    'st_sidebar': fromSidebar.State
}

export const reducer = fromSidebar.reducer;

///create feature selector handle to the complete state

export const getSidebarState = createFeatureSelector<fromSidebar.State>('st_sidebar');

//query from the selector handle
export const getSidebarItemList = createSelector(
    getSidebarState,
    fromSidebar.getSidebarItemList
);

