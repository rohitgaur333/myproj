import { Action } from '@ngrx/store';
import { Header_Menu_Item } from '../model/header.model';

//Action Type constants declarations
export const GET_HEADER='[HEADER] GET_HEADER';
export const GET_HEADER_SUCCESS='[HEADER] GET_HEADER_SUCCESS';
export const GET_HEADER_ERROR='[HEADER] GET_HEADER_ERROR';



//interface of action
export class Interface implements Action {
  readonly type :string;
  public payload?:any;
}
//Action classes implementation

export class GetHeaderAction implements Action {
  readonly type = GET_HEADER;
  constructor() {}
}

export class GetHeaderSuccessAction implements Action {
  readonly type = GET_HEADER_SUCCESS;
  constructor(public payload:Header_Menu_Item) {}
}

export class GetHeaderErrorAction implements Action {
  readonly type = GET_HEADER_ERROR;
  constructor(public payload:string) {}
}
