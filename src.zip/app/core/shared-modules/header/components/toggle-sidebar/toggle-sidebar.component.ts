import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'header-toggle-sidebar',
  templateUrl: './toggle-sidebar.component.html',
  styleUrls: ['./toggle-sidebar.component.css']
})
export class ToggleSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
