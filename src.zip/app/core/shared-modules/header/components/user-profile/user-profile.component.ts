import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';
import { Header_Account_Details } from '../../model/header.model';

@Component({
  selector: 'header-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

@Input() d_account_menu:Header_Account_Details;
@Output() lock:EventEmitter<boolean>=new EventEmitter<boolean>();
@Output() logOut:EventEmitter<boolean>=new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

}
