import { Component, OnInit, Input } from '@angular/core';
import { Header_School_Details } from '../../model/header.model';


@Component({
  selector: 'header-logo-title',
  templateUrl: './logo-title.component.html',
  styleUrls: ['./logo-title.component.css']
})
export class LogoTitleComponent implements OnInit {

  @Input() d_school_detail :Header_School_Details;

  constructor() { }

  ngOnInit() {
  }

}
