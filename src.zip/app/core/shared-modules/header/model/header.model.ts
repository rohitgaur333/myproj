

export interface Header_Menu_Item {
    link_icon:string,
    link_name:string,
    link_url:string,
        
}
export interface Header_Account_Details {
    login_id:string,
    user_name:string,
    image_url:string
}

export interface Header_School_Details {
    name:string,
    short_name:string
}