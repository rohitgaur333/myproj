import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import { AuthService } from '../../../../root/auth-guard/auth.service';

@Injectable()
export class HeaderService {
  
    //temp_query;
    constructor(private http: Http,private authService: AuthService){
        console.log('Search Service Initiated...');
        
    }
        getHeaderMenu(){
        // return this.http.get('http://localhost:4000/student/'+studentRecord)
        // .map(res => res.json());
         console.log('Http Service Call');
        //let headers = new Headers ({ 'Content-Type': 'application/json' });
          let headersObj = new Headers();
    headersObj.set('Content-Type', 'application/x-www-form-urlencoded');
        console.log(this.authService.getToken());
        headersObj.append('x-access-token', this.authService.getToken());
        let options: RequestOptions = new RequestOptions({ headers: headersObj, method: "POST" });
    	var body = JSON.stringify({login_id:"AAS00009"});
    	console.log(body);
     return this.http.post('http://localhost:4000/api/protected/layout/header', body ,options)
    .map(res =>res.json())
    ;
    }
}