import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Actions,Effect,toPayload  } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { HeaderService } from '../services/header.service';
import * as headerAction from '../actions/header.actions';



@Injectable()
export class HeaderEffects {

@Effect()
getHeaderMenu$ :Observable<Action> = this.action$
    .ofType(headerAction.GET_HEADER)
    //.map(toPayload)
    .switchMap(()=>
          this.headerService.getHeaderMenu()
            .map(receivedRecord=>(new headerAction.GetHeaderSuccessAction(receivedRecord)))
            .catch((error)=>Observable.of(new headerAction.GetHeaderErrorAction(error))));

    constructor(private headerService:HeaderService,private action$:Actions){
    }
}


