import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

//ngrx module imports
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//reducer definations import
import { reducer } from './reducer/';

//import components
import { LogoTitleComponent } from './components/logo-title/logo-title.component';
import { ToggleSidebarComponent } from './components/toggle-sidebar/toggle-sidebar.component';
import { NavMenuComponent } from './components/nav-menu/nav-menu.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';

//Header Container Import holding all the Components and related Services
import { HeaderContainer } from './container/header.container';

//effects and services import
import { HeaderEffects } from './effects/header.effect';
import { HeaderService } from './services/header.service';


@NgModule({
imports: [ 
              CommonModule,HttpModule,
              StoreModule.forFeature('st_header',reducer),
              EffectsModule.forFeature([HeaderEffects])
              ],
  declarations: [
              //custom components and container declaration
              HeaderContainer,
              
              LogoTitleComponent,
              ToggleSidebarComponent,
              NavMenuComponent,
              UserProfileComponent
    ],
  exports: [ 
              HeaderContainer
  ],
  providers:[HeaderService]
})

export class HeaderModule { }