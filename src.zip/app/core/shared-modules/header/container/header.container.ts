import { Component,Input } from '@angular/core';
import { Router, RouterLink,ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';
//import { AppState } from './appstate.interface';
import { ShowStudentSearchAction } from '../../../core-modules/student/student-search/actions/student-search.actions';
import { AlertShowAll } from '../../../shared-modules/alert/actions/alert.actions';

import * as headerActions from '../actions/header.actions';

import * as headerModel from '../model/header.model';

import * as fromReducer from '../reducer/';

import * as fromRootReducer from '../../../../root/root-reducers';

//actions file import for account locking/logginout etc
import * as rootActions from '../../../../root/root-actions/root.actions';
import * as loginActions from '../../../../root/root-modules/login/actions/login.actions';

@Component({
  selector: 'header-container',
  template:`
            <header class="main-header">
              <header-logo-title [d_school_detail]="c_school_detail$ | async" ></header-logo-title>
                 <!-- Header Navbar -->
                     <nav class="navbar navbar-static-top" role="navigation">
                          <header-toggle-sidebar></header-toggle-sidebar>
                              <!-- Navbar Right Menu -->
                              <div class="navbar-custom-menu">
                                <header-nav-menu 
                                class="nav navbar-nav"
                                [d_nav_menu]="c_nav_menu$ | async"
                                (navigateClick)="navigateUrl($event)"
                                ></header-nav-menu>
                                <header-user-profile class="nav navbar-nav"
                                [d_account_menu]="c_account_menu$ | async"
                                (lock)="lockAccount()"
                                (logOut)="logOutAccount()"
                                ></header-user-profile>
                              </div>
                      </nav>
              </header>
            `,
})

export class HeaderContainer {

  c_school_detail$:Observable<headerModel.Header_School_Details>;
  c_nav_menu$:Observable<headerModel.Header_Menu_Item[]>;
  c_account_menu$:Observable<headerModel.Header_Account_Details>;
  
  constructor(private _store:Store<fromReducer.State>,private router:Router,private route:ActivatedRoute){
      this._store.dispatch(new headerActions.GetHeaderAction());
    
    this.c_school_detail$=this._store.select(fromReducer.getSchoolDetail);
    this.c_nav_menu$=this._store.select(fromReducer.getHeaderNavMenu);
    this.c_account_menu$=this._store.select(fromRootReducer.getAccountProfile);
     
   }

   logOutAccount(){
    console.log('loggin out');
   }
   lockAccount(){
    console.log('locking out');
    this._store.dispatch(new loginActions.LoginLockedAction(true));
    this._store.dispatch(new rootActions.LockAccountAction(true));
    this.router.navigateByUrl('login');
   }
   navigateUrl(url: string){
     console.log(url);
    switch(url){
      case 'Search':
      {
        if(this.router.url.includes('/core/manage'))
      return this._store.dispatch(new ShowStudentSearchAction());
      else
      {this._store.dispatch(new ShowStudentSearchAction());
      return this.router.navigateByUrl('core/student/search');} 
      }
      case 'Alerts':
       return this._store.dispatch(new AlertShowAll());
      default:
      return this.router.navigateByUrl(url);
    }
    
   }


}
