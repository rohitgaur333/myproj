import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromHeader from './header.reducer';

import * as fromRoot from '../../../../root/root-reducers';

export interface State extends fromRoot.State{
    'st_header': fromHeader.State
}

export const reducer = fromHeader.reducer;

///create feature selector handle to the complete state

export const getHeaderState = createFeatureSelector<fromHeader.State>('st_header');

//query from the selector handle

///////////////////////////////////////////////////////////

export const getHeaderNavMenu = createSelector(
    getHeaderState,
    fromHeader.getNavMenu
);

export const getAccountMenu = createSelector(
    getHeaderState,
    fromHeader.getAccountMenu
)

export const getSchoolDetail = createSelector(
    getHeaderState,
    fromHeader.getSchoolDetail
)
///////////////////////////////////////////////////////////

