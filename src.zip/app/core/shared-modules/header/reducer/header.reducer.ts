import { Action, ActionReducer} from '@ngrx/store';
import * as headerModel from '../model/header.model';

import * as headerActions from '../actions/header.actions';


export interface State {
    school_detail:headerModel.Header_School_Details,
    nav_menu:headerModel.Header_Menu_Item[],
    account_menu: headerModel.Header_Account_Details
   }

/*
const initialState:HeaderInterface={
school_detail:{name:"Valley full",short_name:"VFS"},
nav_menu:[
      {link_name:"Old Dashboard" ,link_icon:"fa fa-dashboard",link_url:"dummy"},
      {link_name:"Settings" ,link_icon:"fa fa-gear",link_url:"/"},
      {link_name:"Alerts",link_icon:"fa fa-bell-o",link_url:"Alerts"},
      {link_name:"Some Feature",link_icon:"fa fa-flag-o",link_url:"/"},
      {link_name:"Search",link_icon:"fa fa-search" ,link_url:"Search"}
    ],
    account_menu:
     {account_id:"S-acbec098"}
}*/

const initialState:State={
    school_detail:{name:"Valley full",short_name:"VFS"},
    nav_menu:[],
        account_menu:
         {account_id:"S-acbec098"}
    }

export function reducer(state=initialState,action:headerActions.Interface){
    switch (action.type){
        case headerActions.GET_HEADER:
        return state;

        case headerActions.GET_HEADER_SUCCESS:
        return Object.assign({},state,{nav_menu:action.payload.nav_menu.data,school_detail:action.payload.school_detail.data[0]});

        case headerActions.GET_HEADER_ERROR:
        return state;

        default:
        return state;

    }
};

export const getNavMenu = (state:State)=> state.nav_menu;
export const getAccountMenu = (state: State)=> state.account_menu;
export const getSchoolDetail = (state:State)=> state.school_detail;