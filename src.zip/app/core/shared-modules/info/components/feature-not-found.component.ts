import { Component, ChangeDetectionStrategy,ChangeDetectorRef } from '@angular/core';



@Component({
  template: `<h2>Feature not found</h2>
 
  `

 // changeDetection:ChangeDetectionStrategy.OnPush  
})
export class FeatureNotFoundComponent {


}