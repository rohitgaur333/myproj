import { Component ,ChangeDetectionStrategy} from '@angular/core';


@Component({

    selector:'test-comp',
    template:`<p>Testing component </p>
                `,    
})

export class TestComponent  {
    constructor(){}
}
