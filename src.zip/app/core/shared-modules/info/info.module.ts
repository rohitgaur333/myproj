import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FeatureNotFoundComponent } from './components/feature-not-found.component';
import { TestComponent } from './components/test.component';

import { InfoRoutes } from './info.routing';

import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

@NgModule ({
    declarations:[
        FeatureNotFoundComponent,
        TestComponent
     ],
    imports:[
            CommonModule,
            // routing definations for info routing
            InfoRoutes
            ],
    exports:[
        FeatureNotFoundComponent,
        TestComponent     
    ]
})


export class InfoModule {}