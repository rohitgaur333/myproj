import { ModuleWithProviders} from '@angular/core';
import { Routes, RouterModule} from '@angular/router';

import { FeatureNotFoundComponent } from './components/feature-not-found.component';
import {TestComponent } from './components/test.component';

const infoRoutes: Routes = [
  //Setting Root Routes for application routing eg "StudentContainer" or default:"PageNotFoundComponent""    
   {path: 'test', component: TestComponent },
   {path: '**', component: FeatureNotFoundComponent },
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const InfoRoutes: ModuleWithProviders = RouterModule.forChild(infoRoutes);

