import { ModuleWithProviders} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { AlertContainer } from './container/alert.container';

const routes: Routes = [
   { path:'notifjkdc',component:AlertContainer }
];

export const AlertRoutes: ModuleWithProviders = RouterModule.forChild(routes);