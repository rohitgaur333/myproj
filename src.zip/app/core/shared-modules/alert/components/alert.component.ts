import { Component, ChangeDetectionStrategy,ChangeDetectorRef,Input,EventEmitter,Output } from '@angular/core';
import {AlertModel} from '../model/alert.model';
import { Observable } from 'rxjs/Observable';

@Component({
  selector:'alert-component',
  template: `
  
 <div *ngIf="d_alertbox_flag || d_alert_flag"  class="box box-success">
     <div class="box-header with-border">
         <h3 class="box-title">Alert Messages</h3>
         <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" (click)="hideAlertBox.emit()"><i class="fa fa-times"></i></button>
            <button *ngIf="!d_alert_flag" type="button" class="btn btn-box-tool" (click)="showAll()"><i class="fa fa-arrow-down"></i></button>
         </div>
      </div>
     <div *ngFor="let list_item of d_alert_list" class="{{getStyle(list_item.type)}}" style="border:1px solid white ;padding: 10px 10px; color:black">
        <b>{{list_item.type}}:  <a *ngIf="list_item.link_content" routerLink="{{list_item.link_url}}">{{list_item.link_content}} </a> </b> {{list_item.alert_body}}
      </div>
  </div>  `
  
 // changeDetection:ChangeDetectionStrategy.OnPush  
})
export class AlertComponent
 {
@Input() d_alert_list:Observable<AlertModel[]>;
@Input() d_alert_flag:boolean;
@Input() d_alertbox_flag:boolean;
@Output() showAllEvent:EventEmitter<boolean>=new EventEmitter<boolean>();
@Output() hideAlertBox:EventEmitter<boolean>=new EventEmitter<boolean>();

getStyle(type:string){
 switch(type){
   case 'SUCCESS':
   return 'alert-success';
   case 'ERROR':
   return 'alert-error';
      case 'WARNING':
   return 'alert-warning';
   default:
   return 'alert-info';
 }
}
constructor(){
  
}

showAll(){
  this.showAllEvent.emit(true);
}

ngOnDestroy(){
  0.
}

}