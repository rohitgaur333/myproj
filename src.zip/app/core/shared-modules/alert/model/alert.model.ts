//interface to hold alert details information

export interface AlertModel{
	type:string;
    link_content?:string,
	link_url?: string;
    alert_body:string,
}