import { Action } from '@ngrx/store';
import { AlertModel } from '../model/alert.model';

//Action Type constants declarations
export const ALERT_APPEND='[AlertModel] ALERT_APPEND';
export const ALERT_RESET='[AlertModel] ALERT_RESET';
export const ALERT_SHOW_ALL='[AlertModel] ALERT_SHOW_ALL';
export const ALERT_SHOW_LATEST='[AlertModel] ALERT_SHOW_LATEST';
export const ALERT_SHOW_ALERTBOX='[AlertModel] ALERT_SHOW_ALERTBOX';
export const ALERT_HIDE_ALERTBOX='[AlertModel] ALERT_HIDE_ALERTBOX';

//Action classes implementation

export class AlertAppendAction implements Action {
  readonly type = ALERT_APPEND;
  constructor(public payload:AlertModel) {}
}

export class AlertReset implements Action {
  readonly type = ALERT_RESET;
  constructor(public payload?:string) {}
}

export class AlertShowAll implements Action{
    readonly type = ALERT_SHOW_ALL;
  constructor(public payload?:string) {}
}

export class AlertShowLatest implements Action{
    readonly type = ALERT_SHOW_LATEST;
  constructor(public payload?:string) {}
}

export class AlertBoxFlag implements Action{
    readonly type = ALERT_SHOW_ALERTBOX;
  constructor(public payload?:string) {}
}

export class AlertBoxHide implements Action{
    readonly type = ALERT_HIDE_ALERTBOX;
  constructor(public payload?:string) {}
}

export type Actions= | AlertAppendAction | AlertReset | AlertShowAll | AlertShowLatest |AlertBoxFlag |AlertBoxHide