import * as fromAlertModel from '../model/alert.model';

import * as AlertAction from '../actions/alert.actions';

export interface State {
	alert_list:fromAlertModel.AlertModel[],
	show_all:boolean,
    alertbox_flag:boolean
}

const alert_list :State= { alert_list: [
    {type:'INFO',link_content:'S0002',link_url:'/student/id_9827387877',alert_body:'created successfully'},
    {type:'INFO',link_content:'S0002',link_url:'/student/id_9827387877',alert_body:'updated successfully'},
    {type:'ERROR',link_content:'S0002',link_url:'/student/id_9827387877',alert_body:'updated successfully'},
    {type:'ERROR',alert_body:'updated successfully'},
    {type:'SUCCESS',alert_body:'updated successfully'},
    {type:'WARNING',alert_body:'updated successfully'}
] ,
show_all:false,alertbox_flag:true
};
                                        
//reducer function for Alert data

export function reducer (state=alert_list,action:AlertAction.Actions):State{
    switch (action.type){
        case AlertAction.ALERT_APPEND:
        return Object.assign({},state,{alert_list:[...state.alert_list,action.payload],alertbox_flag:true});

        case AlertAction.ALERT_RESET:
        return Object.assign({},state,{alert_list:[]});

        case AlertAction.ALERT_SHOW_ALL:
        return Object.assign({},state,{show_all:true});

        case AlertAction.ALERT_SHOW_LATEST:
        return Object.assign({},state,{show_all:false});

        case AlertAction.ALERT_SHOW_ALERTBOX:
        return  Object.assign({},state,{alertbox_flag:true});

         case AlertAction.ALERT_HIDE_ALERTBOX:
        return  Object.assign({},state,{alertbox_flag:false});

        default:
        return state;

    }
};

export const getAlertList = (state:State) => state.alert_list;
export const getAlertFlag = (state:State) => state.show_all;
export const getAlertBoxFlag = (state:State) => state.alertbox_flag;