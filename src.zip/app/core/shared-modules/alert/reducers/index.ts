import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromAlertReducer from './alert.reducer';

import * as fromRoot from '../../../../root/root-reducers/';

export interface State extends fromRoot.State{
    'st_alert': fromAlertReducer.State
}

export const reducer =  fromAlertReducer.reducer;

///create feature selector handle to the complete state

export const getAlertState = createFeatureSelector<fromAlertReducer.State>('st_alert');

//query from the selector handle
export const getAlertList = createSelector(
    getAlertState,
    fromAlertReducer.getAlertList
);

export const getAlertFlag= createSelector(
    getAlertState,
    fromAlertReducer.getAlertFlag
);

export const getAlertBoxFlag= createSelector(
    getAlertState,
    fromAlertReducer.getAlertBoxFlag
);

export const getFilteredList = createSelector(
    getAlertList,getAlertFlag,
    (list,flag)=>{
        if(flag)
        return list;
        else
        return [list[list.length-1]];
    }
);