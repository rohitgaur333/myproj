import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs/Observable';
//import * as state from '../reducers/alert.reducer';
//Below will refer to index.ts in specified directory
import * as fromAlert from '../reducers';

import { AlertModel } from '../model/alert.model';
import * as alertAction from '../actions/alert.actions';

@Component({
    selector:'alert-container',
    template:`
              <alert-component [d_alert_list]="c_alert_list | async"
                               [d_alert_flag]="c_alert_flag | async"
                               [d_alertbox_flag]="c_alertbox_flag | async"
                               (showAllEvent)="updateShowAll()"
                               (hideAlertBox)="hideAlertBox()"
              ></alert-component>

              <!--button (click)="add()">Add item</button-->
                `
})

export class AlertContainer {

     c_alert_list:Observable<AlertModel[]>;
     c_alert_flag:Observable<boolean>;
     c_alertbox_flag:Observable<boolean>;

    //container component to be passed to dump component properties
    constructor(private _store:Store<fromAlert.State>){
            this.c_alert_list=this._store.select(fromAlert.getFilteredList);
            this.c_alert_flag=this._store.select(fromAlert.getAlertFlag);
             this.c_alertbox_flag=this._store.select(fromAlert.getAlertBoxFlag);

            this.c_alert_list.subscribe(data=>
                setTimeout(()=>
                this._store.dispatch(new alertAction.AlertBoxHide())
                ,10000 )
            );
    }

    updateShowAll(){
        this._store.dispatch(new alertAction.AlertShowAll());
    }

    hideAlertBox(){
        this._store.dispatch(new alertAction.AlertBoxHide());
        this._store.dispatch(new alertAction.AlertShowLatest());
    }

    add(){
        let item:AlertModel={type:'Error',alert_body:'asjbchjdn'};
        this._store.dispatch(new alertAction.AlertAppendAction(item));
    }
}