import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { Routes, RouterModule} from '@angular/router';



//ngrx module import
import { StoreModule } from '@ngrx/store';

//container import
import {  AlertContainer}   from './container/alert.container';
//component import
//import { StudentRegisterComponent } from './components/student-register.component';
//routing import
import {AlertRoutes } from './alert.routing';

import {AlertComponent} from './components/alert.component';
//reducer import
import { reducer } from './reducers/alert.reducer';

@NgModule({
  imports:      [
    CommonModule,
    RouterModule,
    AlertRoutes,
    StoreModule.forFeature('st_alert',reducer),
    //StudentRegisterRoutes,   
  ],
  declarations: [
    AlertContainer,
    AlertComponent
    //StudentRegisterComponent,
    
    ],
  exports: [AlertContainer],
  
})

export class AlertModule { }