import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl:'./core.container.html',
    styleUrls:[]
  
})
export class CoreContainer {
 
  constructor(){
 
  }
}
