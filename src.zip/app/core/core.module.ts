import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
//import { RouterModule } from '@angular/router';

//ngrx module imports
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//Importing core container which holds all the core modules calls
import { CoreContainer } from './core.container';

//importing shared modules definations(these module will be fixed to application once the appliation loads)
//import { LayoutModule } from './shared-modules/layout/layout.module';
import { HeaderModule } from './shared-modules/header/header.module';
import { SidebarModule } from './shared-modules/sidebar/sidebar.module';

import { ModalModule } from './shared-modules/modal/modal.module';
import { AlertModule } from './shared-modules/alert/alert.module';
//Core routing defination for lazy loading feature modules
import { CoreRoutes } from './core.routing';


import { MyDatePickerModule } from 'mydatepicker';

@NgModule({
  declarations: [
    CoreContainer
  ],
  imports: [
    CommonModule,
    ModalModule,
    //RouterModule,
    CoreRoutes,
    StoreModule.forFeature('core',{val:'state'}),
    //LayoutModule,
    HeaderModule,
    SidebarModule,
    AlertModule,
    MyDatePickerModule
    //EffectsModule.forRoot([TodoEffects]),
  ],
  providers: [],
  exports:[],
  bootstrap: [CoreContainer]
})
export class CoreModule { }
