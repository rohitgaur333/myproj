import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class StudentHttpService {
    
    //temp_query;
    constructor(private http: Http){
        console.log('Search Service Initiated...');
        
    }
    getStudent(SID:string){
        return this.http.get('http://localhost:4000/student/details'+SID)
        .map(res => res.json());
    }


}