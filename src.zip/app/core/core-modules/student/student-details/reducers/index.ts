import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromStudentDetails from './student-details.reducer';

import * as fromRoot from '../../../../../root/root-reducers/';

export interface State extends fromRoot.State{
    'st_student_details': fromStudentDetails.State
}

export const reducer = fromStudentDetails.reducer;


///create feature selector handle to the complete state

export const getStudentDetailsState = createFeatureSelector<fromStudentDetails.State>('st_student_details');

//query from the selector handle
export const getStudentRecord = createSelector(
    getStudentDetailsState,
    (state:fromStudentDetails.State) => state.student_record
);

export const getIsLoading = createSelector(
    getStudentDetailsState,
    (state:fromStudentDetails.State) => state.is_loading
);

export const getIsEditing = createSelector(
    getStudentDetailsState,
    (state:fromStudentDetails.State) => state.is_editing
);