//import { Action, ActionReducer} from '@ngrx/store';

import { StudentRecordModel } from '../model/student-details.model';

import * as StudentDetailsAction from '../actions/student-details.actions';

export interface State {
	student_record:StudentRecordModel,
	is_loading:boolean,
	is_editing:boolean
}

////////selected student reducer
const initial_selected_student :State= { student_record: {
                                        _id:'597b605d145c0a8e6a0c5510',
                                        SID:"S-1234",
                                        fname: "Rohit",
                                        mname:'',
                                        lname: "Gaur",
                                        gender: "Male",
                                        dob:"2017-04-04T18:30:00.000Z",
                                        class:"3",
                                        section:"B",
                                        student_mobile:9811536239,
                                        father_name:"Mr R A Gaur",
                                        father_mobile:9811536239},
                                        is_loading:false,
                                        is_editing:false
                                    };
                                        
//reducer function for selected student data

export function reducer (state=initial_selected_student,action:StudentDetailsAction.Interface):State{
    switch (action.type){
        case StudentDetailsAction.GET_STUDENT_RECORD:
        return Object.assign({},state,{is_loading:true});

        case StudentDetailsAction.GET_STUDENT_RECORD_SUCCESS:
        return Object.assign({},state,{student_record:action.payload,is_loading:false});

        case StudentDetailsAction.GET_STUDENT_RECORD_ERROR:
        console.log('error fetching data');
        return state;

        case  StudentDetailsAction.ENABLE_STUDENT_LOADING:
        return Object.assign({},state,{is_loading:true});

        case StudentDetailsAction.DISABLE_STUDENT_LOADING:
        return Object.assign({},state,{is_loading:false});

        case StudentDetailsAction.ENABLE_EDIT_MODE:
        return Object.assign({},state,{is_editing:true});

        case StudentDetailsAction.DISABLE_EDIT_MODE:
        return Object.assign({},state,{is_editing:false});

        default:
        return state;

    }
};

export const getStudentDetails = (state:State) => state.student_record;
export const getStudentDetailsLoading = (state:State) => state.is_loading;
export const getStudentDetailsEditing = (state:State) => state.is_editing;