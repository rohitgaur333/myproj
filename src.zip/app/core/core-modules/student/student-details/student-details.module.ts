import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule} from '@angular/router';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule } from '../../../shared-modules/modal/modal.module';

//ngrx module import
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//container import
import { StudentDetailsContainer }   from './container/student-details.container';
//component import
import { StudentDetailsComponent } from './components/student-details.component';
//routing import
import { StudentDetailsRoutes } from './student-details.routing';
//reducer import
import { reducer } from './reducers/';


@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule,
    MyDatePickerModule,
    ModalModule,
    StoreModule.forFeature('st_student_details',reducer),
    StudentDetailsRoutes,   
  ],
  declarations: [
    StudentDetailsContainer,
    StudentDetailsComponent,
    
    ],
  exports: []
})

export class StudentDetailsModule { }