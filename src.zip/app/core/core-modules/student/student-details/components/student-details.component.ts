import { ViewChild,ElementRef,Component,EventEmitter,ChangeDetectorRef,ChangeDetectionStrategy,Input,Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { IMyDpOptions,IMyDate} from 'mydatepicker';
import { Router,ActivatedRoute,Params} from '@angular/router';
import { DatePipe } from '@angular/common';
import { isEqual, differenceWith,difference } from 'lodash';

import { Store } from '@ngrx/store';

import { StudentRecordModel } from '../model/student-details.model';


@Component({
 moduleId: module.id,
  selector: 'student-details',
  templateUrl:'./student-details.component.html',
  styleUrls:['./student-details.component.css'],
  providers:[DatePipe],
  changeDetection:ChangeDetectionStrategy.Default
})
export class StudentDetailsComponent  { 
   
   //local variable declaration
    studentDetailForm:FormGroup;
    l_is_editing:boolean;
    l_student_record:StudentRecordModel;
    //popup variable
    isPopupVisible:BehaviorSubject<boolean>=new BehaviorSubject<boolean>(false);
    isPopupVisible$=this.isPopupVisible.asObservable();
    popupTitle:String='';

    //datepicker options eg format of the date
    myDatePickerOptions: IMyDpOptions = {
            dateFormat: 'dd-mm-yyyy',
            editableDateField:false};

    //input variable for date of birth field and subsequent data stream variable for datepicker input
    l_indate:BehaviorSubject<string>=new BehaviorSubject<string>('');
    l_indate$=this.l_indate.asObservable();
    

   @Input() set d_student_record (value : StudentRecordModel){
          this.l_student_record=Object.assign({},value);      
          this.studentDetailForm.patchValue(value);
          var temp =new Date(value.dob);
                    
          let latest_date =this.datepipe.transform(value.dob, 'dd-MM-yyyy');
          console.log(latest_date);

          this.l_indate.next(latest_date);
          console.log(this.studentDetailForm.value);
          }
   @Input() d_is_loading:boolean;
   @Input() set d_is_editing(value :boolean){
      this.l_is_editing=value;
      if(value)
      {
        this.studentDetailForm.enable();
        this.studentDetailForm.controls['SID'].disable();
      }
      else
      this.studentDetailForm.disable();
   }

   //Output event definations
   @Output() editForm:EventEmitter<boolean> = new EventEmitter<boolean>();
   @Output() saveForm:EventEmitter<StudentRecordModel> = new EventEmitter<StudentRecordModel>();
     
    constructor(private formBuilder: FormBuilder,
                private ref:ChangeDetectorRef,
                public datepipe: DatePipe){

                this.studentDetailForm = this.formBuilder.group({
                _id:['',Validators.required],
                SID:[{value: '', disabled: true},Validators.required],
                fname:['',Validators.required],
                mname: '',
                lname:['',Validators.required],
                gender:['',Validators.required],
                dob:['',Validators.required],
                class:[''],
                section:[''],
                student_mobile:['',Validators.required],
                father_name:['',Validators.required],
                father_mobile:['',Validators.required]
              });

      //mark dob datepicker child component as touched and patching student record to form for the first place
        this.studentDetailForm.controls['dob'].markAsTouched();
      }//constructor ends

    ngOnInit() {
      console.log('insideinit');
        //initialize the form for the value to be updated.
      
     }

      //updating value on form on date update event from datepicker
  dateUpdated(dateValue){
    this.studentDetailForm.controls['dob'].patchValue(dateValue);
    this.l_indate.next(dateValue);
  }

  //styling the date form fields on basis of validation checks 
  showValidationErrorDatepickerStyle(property:string):string{
     if(!this.l_is_editing){
        return 'datepicker-disable';
        }
      let control:any=this.studentDetailForm.controls[property];
        return (control.valid) ? 'datepicker-success' :'datepicker-error';
    }
    //styling the date form fields on basis of validation checks 
  showValidationErrorStyle(property:string):string{
     if(!this.l_is_editing){
        return 'input-disable';
      }
      if(property=='SID')
      return 'input-success';
      
      let control:any=this.studentDetailForm.controls[property];
      return (control.valid) ? 'input-success' :'input-error';
    }  
  //to show error message if any on validation  check
  showValidationErrorMessage(property:string):boolean{
  if(!this.l_is_editing){
    return false;
  }
  let control:any=this.studentDetailForm.controls[property];
  return !control.valid && control.touched;
}
//to save updated student record
saveStudentDetail(){
    let tempStudentRecord:StudentRecordModel;
    tempStudentRecord=this.studentDetailForm.value;
    tempStudentRecord.SID=this.l_student_record.SID;
    
    if(!isEqual(tempStudentRecord,this.l_student_record)){
      console.log('changes done');
      this.saveForm.emit(this.studentDetailForm.value);
    }
    else
    {
      this.isPopupVisible.next(true);
      this.popupTitle='Information';
      console.log('No Change Done !!!');
    }
}  
//editing and enabling student record
editStudentRecord(){
  this.editForm.emit(true);
  this.studentDetailForm.controls['SID'].disable();
}
//cancel if in edit mode and revert all changed done to student record
cancelEdit(){
  this.studentDetailForm.patchValue(this.l_student_record);
  this.l_indate.next(this.l_student_record.dob);
  this.editForm.emit(false);

}
showPopup(){
  this.isPopupVisible.next(true);
  return this.isPopupVisible;
}
cancelDialog(){
  console.log('cancel hit');
  this.isPopupVisible.next(false);
}
getValidationStatus(){
  
  return  ;
}

ngOnDestroy(){
  //  this.storeinstance$.unsubscribe();
  //this.l_indate.unsubscribe();
  //this.isPopupVisible.unsubscribe();
  }

  }
