import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Actions,Effect,toPayload  } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { StudentHttpService } from '../services/student-details.service';
import * as studentDetailsAction from '../actions/student-details.actions';

@Injectable()
export class StudentDetailsEffects {

@Effect()
getStudentDetails$ :Observable<Action> = this.action$
    .ofType(studentDetailsAction.GET_STUDENT_RECORD)
    .debounceTime(400)
    .map(toPayload)
    .switchMap(SID=>
          this.studentDetailsService.getStudent(SID)
            .map(receivedRecord=>({type:studentDetailsAction.GET_STUDENT_RECORD_SUCCESS,payload:receivedRecord}))
            .catch(()=>Observable.of({type:studentDetailsAction.GET_STUDENT_RECORD_ERROR})));

    constructor(private studentDetailsService:StudentHttpService,private action$:Actions){
    }
}