import { Action } from '@ngrx/store';
import { StudentRecordModel } from '../model/student-details.model';

//Action Type constants declarations
export const GET_STUDENT_RECORD='[StudentRecordModel] GET STUDENT';
export const GET_STUDENT_RECORD_SUCCESS='[StudentRecordModel] GET_STUDENT_SUCCESS';
export const GET_STUDENT_RECORD_ERROR='[StudentRecordModel] GET_STUDENT_ERROR';

export const ENABLE_EDIT_MODE='[StudentRecordModel] ENABLE_EDIT_MODE';
export const DISABLE_EDIT_MODE='[StudentRecordModel] DISABLE_EDIT_MODE';

export const ENABLE_STUDENT_LOADING='[StudentRecordModel] ENABLE_STUDENT_LOADING';
export const DISABLE_STUDENT_LOADING='[StudentRecordModel] DISABLE_STUDENT_LOADING';


//interface of action
export class Interface implements Action {
  readonly type :string;
  public payload?:any;
}
//Action classes implementation

export class GetStudentAction implements Action {
  readonly type = GET_STUDENT_RECORD;
  constructor(public payload:string) {}
}

export class GetStudentSuccessAction implements Action {
  readonly type = GET_STUDENT_RECORD_SUCCESS;
  constructor(public payload:StudentRecordModel) {}
}

export class GetStudentErrorAction implements Action {
  readonly type = GET_STUDENT_RECORD_ERROR;
  constructor() {}
}

export class EnableEditModeAction implements Action {
  readonly type = ENABLE_EDIT_MODE;
  constructor() {}
}

export class DisableEditModeAction implements Action {
  readonly type = DISABLE_EDIT_MODE;
  constructor() {}
}

export class EnableStudentLoadingAction implements Action {
  readonly type = ENABLE_STUDENT_LOADING;
  constructor() {}
}

export class DisableStudentLoadingAction implements Action {
  readonly type = DISABLE_STUDENT_LOADING;
  constructor() {}
}

