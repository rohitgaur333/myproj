import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs/Observable';

import * as state from '../reducers/student-details.reducer';
import * as fromStudentDetails from '../reducers';

import { StudentRecordModel } from '../model/student-details.model';
import * as studentDetailsAction from '../actions/student-details.actions';



@Component({
    selector:'student-container',
    template:` <student-details
                    [d_student_record]="s_student_record | async"
                    [d_is_loading]="s_is_loading | async"
                    [d_is_editing]="s_is_editing | async"
                    (editForm)="editStudentRecord($event)"
                    (saveForm)="saveStudentRecord($event)"
                    ></student-details>
                `
})

export class StudentDetailsContainer {

    storeinstance$;

    //container component to be passed to dump component properties
    s_is_loading:Observable<boolean>;
    s_is_editing:Observable<boolean>;
    s_student_record:Observable<StudentRecordModel>;

    constructor(private _store:Store<fromStudentDetails.State>){
        this.s_student_record=this._store.select(fromStudentDetails.getStudentRecord);
        this.s_is_loading=this._store.select(fromStudentDetails.getIsLoading);
        this.s_is_editing=this._store.select(fromStudentDetails.getIsEditing);

    }
    ngOnInit() {
        this.s_student_record.subscribe(data=>{
            console.log("record");            
            console.log(data);
        });

           this.s_is_editing.subscribe(data=>{
            console.log("editing"); 
            console.log(data);
        })
           this.s_is_loading.subscribe(data=>{
            console.log("loading"); 
            console.log(data);
        })
    }

    editStudentRecord(value:boolean){
        if(value)
        this._store.dispatch(new studentDetailsAction.EnableEditModeAction());
        else
        this._store.dispatch(new studentDetailsAction.DisableEditModeAction());
    }

    saveStudentRecord(studentRecord:StudentRecordModel){
        console.log('saving form');
    }
}