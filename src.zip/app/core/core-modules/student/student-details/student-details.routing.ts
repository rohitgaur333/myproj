import { ModuleWithProviders} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { StudentDetailsContainer } from './container/student-details.container';

const routes: Routes = [
   { path:'',component:StudentDetailsContainer }
];

export const StudentDetailsRoutes: ModuleWithProviders = RouterModule.forChild(routes);