import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable} from 'rxjs';
//sub-module specific imports
import * as fromStudentSearch from '../reducers/';
import * as searchState from '../model/student-search.model';
import * as searchStudentAction from '../actions/student-search.actions';

@Component({
  selector: 'student-search',
  templateUrl: './student-search.container.html',
  styleUrls: ['./student-search.container.css']
})
export class StudentSearchContainer implements OnInit {

  c_filter:searchState.StudentSearchFilter={
             "SID":true,
             "fname":true,
             "lname":true,
             "class":true,
             "section":true,
             "dob":true
        }

  //input related fields
  c_search_query$:Observable<searchState.StudentSearchQuery>;
  //search view related variables
  c_view_mode$:Observable<string>;

  //search result related properties
  c_search_result_list$:Observable<searchState.StudentSearchRecord[]>;
  c_search_result_loading$:Observable<boolean>;

  c_is_visible:Observable<boolean>;
  
  constructor(private _store:Store<fromStudentSearch.State>) { 
    //assign input properties
    this.c_view_mode$=this._store.select(fromStudentSearch.getViewMode);
    this.c_search_query$=this._store.select(fromStudentSearch.getSearchInputQuery);

    //getting result set observables
    this.c_search_result_list$=this._store.select(fromStudentSearch.getSearchResultList);
    this.c_search_result_loading$=this._store.select(fromStudentSearch.getSearchResultLoading);

    //visibility assignment
    this.c_is_visible=this._store.select(fromStudentSearch.getVisibility);
  }

  ngOnInit() {
  }

  pushSearchQuery(d_query:searchState.StudentSearchQuery){
    console.log('search action');
    let criteria:searchState.StudentSearchCriteria;
    criteria={
      query:d_query,
      filter:this.c_filter
    }
    console.log(criteria);
    this._store.dispatch(new searchStudentAction.SearchStudentAction(criteria));
  }
  pushModeUpdate(mode:string){
    if(mode=='min')
      this._store.dispatch(new searchStudentAction.MinViewModeAction());
    if(mode=='max')
      this._store.dispatch(new searchStudentAction.MaxViewModeAction());
    if(mode=='hide')
    this._store.dispatch(new searchStudentAction.HideStudentSearchAction());
  } 
  //method for styling
  getViewStyle(){
  if("min")
    return "col-md-3";
  else
    return "col-md-12";
  }


}
