export interface StudentSearchViewMode {
	view_mode:string,
	is_visible:boolean
}
//search result interfaces
export interface StudentSearchResult {
	result_list:StudentSearchRecord[],
	loading:boolean
}

export interface StudentSearchRecord  {
	_id:string,
	SID:string,
	fname: string;
	lname: string;
	class?:string,
	section?:string,
	dob:string;
}


//search input interfaces
export interface StudentSearchInput {
	search_criteria:StudentSearchCriteria,
	loading:boolean
}

export interface StudentSearchCriteria {
	query:StudentSearchQuery,
	filter:StudentSearchFilter
}

export interface StudentSearchFilter{
	  	SID?:boolean,
        fname?:boolean,
        lname?:boolean,
        class?:boolean,
        section?:boolean,
        dob?:boolean
}

export interface StudentSearchQuery {
	SID?:string,
	fname?:string
}
