import { ModuleWithProviders} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { StudentSearchContainer } from './container/student-search.container';

const routes: Routes = [
   { path:'',component:StudentSearchContainer }
];

export const StudentSearchRoutes: ModuleWithProviders = RouterModule.forChild(routes);