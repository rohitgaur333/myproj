import { Action } from '@ngrx/store';
import { StudentSearchResult } from '../model/student-search.model';

//Action Type constants declarations
//input component related actions
export const SEARCH_STUDENT='[StudentSearch] SEARCH STUDENT';

export const SEARCH_STUDENT_SUCCESS='[StudentSearch] SEARCH_STUDENT_SUCCESS';
export const SEARCH_STUDENT_ERROR='[StudentSearch] SEARCH_STUDENT_ERROR';

export const ENABLE_SEARCH_INPUT_LOADING='[StudentSearch] ENABLE_SEARCH_INPUT_LOADING';
export const DISABLE_SEARCH_Input_LOADING='[StudentSearch] DISABLE_SEARCH_INPUT_LOADING';


//result actions

export const LOAD_SEARCH_STUDENT_RESULTS='[StudentSearch] LOAD_SEARCH_STUDENT_RESULTS';

export const ENABLE_SEARCH_RESULT_LOADING='[StudentSearch] ENABLE_SEARCH_RESULT_LOADING';
export const DISABLE_SEARCH_RESULT_LOADING='[StudentSearch] DISABLE_SEARCH_RESULT_LOADING';


//view mode related actions
export const MIN_VIEW_MODE='[StudentSearch] MIN VIEW MODE';
export const MAX_VIEW_MODE='[StudentSearch] MAX VIEW MODE';

export const HIDE_STUDENT_SEARCH='[StudentSearch] HIDE STUDENT SEARCH';
export const SHOW_STUDENT_SEARCH='[StudentSearch] SHOW STUDENT SEARCH';

export const TOGGLE_STUDENT_SEARCH='[StudentSearch] TOGGLE STUDENT SEARCH';


//interface of action
export class Interface implements Action {
  readonly type :string;
  public payload?:any;
}

//Action classes implementation
export class SearchStudentAction implements Action {
  readonly type = SEARCH_STUDENT;
  constructor(public payload:{}) {}
}

export class LoadSearchStudentResultsAction implements Action {
  readonly type = LOAD_SEARCH_STUDENT_RESULTS;
  constructor(public payload: StudentSearchResult[]) {}
}

export class SearchStudentSuccessAction implements Action {
  readonly type = SEARCH_STUDENT_SUCCESS;
  constructor() {}
}

export class SearchStudentErrorAction implements Action {
  readonly type = SEARCH_STUDENT_ERROR;
  constructor() {}
}

export class EnableSearchResultLoadingAction implements Action {
  readonly type = ENABLE_SEARCH_RESULT_LOADING;
  constructor() {}
}

export class DisableSearchResultLoadingAction implements Action {
  readonly type = DISABLE_SEARCH_RESULT_LOADING;
  constructor() {}
}

export class EnableSearchInputLoadingAction implements Action {
  readonly type = ENABLE_SEARCH_RESULT_LOADING;
  constructor() {}
}

export class DisableSearchResultInputAction implements Action {
  readonly type = DISABLE_SEARCH_RESULT_LOADING;
  constructor() {}
}

export class MaxViewModeAction implements Action {
  readonly type = MAX_VIEW_MODE;
  constructor() {}
}

export class MinViewModeAction implements Action {
  readonly type = MIN_VIEW_MODE;
  constructor() {}
}

export class HideStudentSearchAction implements Action {
  readonly type = HIDE_STUDENT_SEARCH;
  constructor() {}
}
export class ShowStudentSearchAction implements Action {
  readonly type = SHOW_STUDENT_SEARCH;
  constructor() {}
}