import { Component, OnInit, Input, Output,ChangeDetectionStrategy } from '@angular/core';
import { StudentSearchResult } from '../../model/student-search.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class SearchResultComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router) { }

  @Input() d_resultList :StudentSearchResult[];
  @Input() d_loading:boolean;
  @Input() d_viewMode:string;

  ngOnInit() {
    //console.log(this.resultList);
  }
getViewStyle(){
  console.log(this.d_viewMode);
  if(this.d_viewMode=="max")
    return "col-md-12";
  else
    return "col-md-4";
}
  getViewMode(){
  if(this.d_viewMode=="max")
    return true;
  else
    return false
  }
  navigateTo(_id:string){
      console.log(_id);
      this.router.navigateByUrl('student/details/'+_id);
    }
  getResultCount(){
    return this.d_resultList.length;
  }
  getSize(){
    //if(this.viewMode=="max")
      //return col-md-3 : col-md-12
  }
}
