import { Component, OnInit,Input,Output,ChangeDetectionStrategy,EventEmitter } from '@angular/core';
import { BehaviorSubject,Observable,Subject } from 'rxjs';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'search-input',
  templateUrl: './search-input.component.html',
  styleUrls: ['./search-input.component.css']
})
export class SearchInputComponent implements OnInit {
  
  searchForm:FormGroup;
  iconClass:string='';

  constructor(private fb:FormBuilder) { 
    
    this.searchForm=this.fb.group({
      SID:[''],
      fname:['']
    });
}
  
  @Output() searchCriteria : EventEmitter<{}>=new EventEmitter<{}>();
  @Input()  d_viewMode:string;
  @Output() viewModeUpdate: EventEmitter<string>=new EventEmitter<string>();
  @Input() d_search_query ;

  ngOnInit() {
      
     if(this.d_search_query)
      this.searchForm.patchValue(this.d_search_query);

      this.searchForm.valueChanges.subscribe(searchData=>{
        this.fireSearch();
    });
  }

  chagne(val){
    console.log(val);
  }

fireSearch(){
  this.searchCriteria.emit(this.searchForm.value);    
}
toggleView(){
  if(this.d_viewMode == 'min'){
     this.viewModeUpdate.emit('max');
    }
  if(this.d_viewMode == 'max'){
    this.viewModeUpdate.emit('min');
  }
  }
//method for styling
getViewStyle(){
  if(this.d_viewMode=="min")
    return "col-md-3";
  else
    return "col-md-12";
}
getIconClass(){
  if(this.d_viewMode == 'min'){
     return this.iconClass="fa fa-clone";
    }
  if(this.d_viewMode == 'max'){
    return this.iconClass="fa fa-minus";
  }
}

searchBoxMode(){
  if(this.d_viewMode=="min")
    return "col-md-10";
  else
    return "col-md-3";
}

ngOnDestroy(){
  
  }
}


//(keyup)="chagne(sid.value)"