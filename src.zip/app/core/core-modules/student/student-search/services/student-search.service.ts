import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs';

@Injectable()
export class StudentSearchService {
    
    temp_query;
    constructor(private http: Http){
        console.log('Search Service Initiated...');
        
    }
    findStudentCustom(criteria){
        console.log('Http Service Call');
        let headers = new Headers ({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
    	var body = JSON.stringify(criteria);
    	console.log(body);
     return this.http.post('http://localhost:4000/student/customquery', body ,options)
    .map(res =>res.json()
    );
    }

}