import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule} from '@angular/router';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule } from '../../../shared-modules/modal/modal.module';

//ngrx module import
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//container import
import { StudentSearchContainer }   from './container/student-search.container';
//component import
import { SearchInputComponent } from './components/search-input/search-input.component';
import { SearchResultComponent } from './components/search-result/search-result.component';
//routing import
import { StudentSearchRoutes } from './student-search.routing';
//reducer import
import { reducer } from './reducers/';
//effects import
import { StudentSearchEffects } from '../student-search/effects/student-search.effect';
//service module
import { StudentSearchService } from './services/student-search.service';

@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule,
    MyDatePickerModule,
    ModalModule,
    //feature reducer plugin and initialize
    StoreModule.forFeature('st_student_search',reducer),
    //effects run
    EffectsModule.forFeature([StudentSearchEffects]),
    StudentSearchRoutes,   
  ],
  declarations: [
    StudentSearchContainer,
    SearchInputComponent,
    SearchResultComponent
    ],
  exports: [StudentSearchContainer],
  providers:[StudentSearchService]
})

export class StudentSearchModule { }