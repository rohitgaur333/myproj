import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Actions,Effect,toPayload  } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { StudentSearchService } from '../services/student-search.service';
import * as studentSearchAction from '../actions/student-search.actions';

@Injectable()
export class StudentSearchEffects {

@Effect() 
findStudent$ :Observable<Action> = this.action$
    .ofType(studentSearchAction.SEARCH_STUDENT)
    .debounceTime(400)
    .map(toPayload)
    .switchMap(query=>
          this.studentSearchService.findStudentCustom(query)
            .map(receivedRecord=>({type:studentSearchAction.SEARCH_STUDENT_SUCCESS,payload:receivedRecord}))
            .catch(()=>Observable.of({type:studentSearchAction.SEARCH_STUDENT_ERROR}))
            );

            constructor(private studentSearchService:StudentSearchService,private action$:Actions){
    }
}