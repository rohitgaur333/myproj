//import { Action, ActionReducer} from '@ngrx/store';
import { createSelector } from '@ngrx/store';

import  * as SearchState from '../model/student-search.model';

import * as SearchStudentAction from '../actions/student-search.actions';



////////reducer's initial state
const initial_search_result_list :SearchState.StudentSearchResult={
                            result_list:[{
                                        _id:"597b605d145c0a8e6a0c5506",
                                        SID:"S-1234",
                                        fname: "Rohit",
                                        lname: "Gaur",
                                        dob:"21-06-1990",
                                        class:"3",
                                        section:"B"},
                                        {
                                        _id:'597b605d145c0a8e6a0c550a',
                                        SID:"S-1239",
                                        fname: "Rahul",
                                        lname: "Singh",
                                        dob:"11-09-1991",
                                        class:"3",
                                        section:"B"},
                                        {
                                            _id:'597b605d145c0a8e6a0c5510',
                                        SID:"S-1239",
                                        fname: "Rahul",
                                        lname: "Singh",
                                        dob:"11-09-1991",
                                        class:"3",
                                        section:"B"},
                                        {
                                            _id:'597b605d145c0a8e6a0c5510',
                                        SID:"S-1239",
                                        fname: "Rahul",
                                        lname: "Singh",
                                        dob:"11-09-1991",
                                        class:"3",
                                        section:"B"}
                                        ],
                            loading:false
        }   

//reducer function for search student data

export function reducer  (state=initial_search_result_list,action:SearchStudentAction.Interface):SearchState.StudentSearchResult{
        switch (action.type){
        case SearchStudentAction.SEARCH_STUDENT:
        return state;

        case SearchStudentAction.SEARCH_STUDENT_SUCCESS:
        console.log(action.payload);
        return Object.assign({},state,{result_list:action.payload});

        default:
        return state;

    }
};

export const getSearchResult            = (state:SearchState.StudentSearchResult) => state.result_list;
export const getSearchResultLoading     = (state:SearchState.StudentSearchResult) => state.loading;