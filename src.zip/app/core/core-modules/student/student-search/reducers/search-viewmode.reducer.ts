import { createSelector } from '@ngrx/store';

import * as StudentSearchAction from '../actions/student-search.actions';
import  * as SearchState from '../model/student-search.model';

////////reducer's initial state
const initial_viewMode :SearchState.StudentSearchViewMode ={
        view_mode:'min',
        is_visible:true
        };
//reducer function for search student data
export function reducer  (state=initial_viewMode,action:StudentSearchAction.Interface):SearchState.StudentSearchViewMode{
    switch (action.type){
        
        case StudentSearchAction.MAX_VIEW_MODE:
        return Object.assign({},state,{view_mode:'max'});

        case StudentSearchAction.MIN_VIEW_MODE:
        return Object.assign({},state,{view_mode:'min'});

        case StudentSearchAction.HIDE_STUDENT_SEARCH:
        return Object.assign({},state,{is_visible:false});

        case StudentSearchAction.SHOW_STUDENT_SEARCH:
        return Object.assign({},state,{is_visible:true});

        case StudentSearchAction.TOGGLE_STUDENT_SEARCH:
        return Object.assign({},state,{is_visible:!state.is_visible});

        default:
        return state;

    }
};

export const getViewMode = (state:SearchState.StudentSearchViewMode) =>   state.view_mode;
export const getVisibility = (state:SearchState.StudentSearchViewMode) =>   state.is_visible;