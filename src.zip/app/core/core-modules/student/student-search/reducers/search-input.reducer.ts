//import { Action, ActionReducer} from '@ngrx/store';
import { createSelector } from '@ngrx/store';

import * as StudentSearchAction from '../actions/student-search.actions';

import  * as SearchState from '../model/student-search.model';

////////reducer's initial state
const initial_search_input :SearchState.StudentSearchInput ={
                        search_criteria:{
                            query:{SID:'',fname:''},
                            filter:{}
                        },
                        loading:false                                      
            };
//reducer function for search student data
export function reducer  (state=initial_search_input,action:StudentSearchAction.Interface):SearchState.StudentSearchInput{
    switch (action.type){
        case StudentSearchAction.SEARCH_STUDENT:
        return Object.assign({},state,{search_criteria:action.payload});

        case StudentSearchAction.ENABLE_SEARCH_INPUT_LOADING:
        return Object.assign({},state,{loading:true});

        default:
        return state;

    }
};

export const getSearchCriteria = (state:SearchState.StudentSearchInput) =>   state.search_criteria;
export const getSearchQuery = createSelector(
    getSearchCriteria,
    (criteria)=>{
        return criteria.query
    }
);
export const getSearchFilter = createSelector(
    getSearchCriteria,
    (criteria)=>{
        return criteria.filter
    }
);
export const getInputLoading = (state:SearchState.StudentSearchInput) =>   state.loading;