import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromSearchInput from './search-input.reducer';
import * as fromSearchResult from './search-result.reducer';
import * as fromSearchViewMode from './search-viewmode.reducer';

import * as fromRoot from '../../../../../root/root-reducers/';

import  * as SearchState from '../model/student-search.model';

export interface StudentSearchState {
            search_input:SearchState.StudentSearchInput,
            search_result:SearchState.StudentSearchResult,
            search_viewmode:SearchState.StudentSearchViewMode
    }
export interface State extends fromRoot.State{
    st_student_search : StudentSearchState
}

export const reducer  = {
                        search_input:fromSearchInput.reducer,
                        search_result:fromSearchResult.reducer,
                        search_viewmode:fromSearchViewMode.reducer
        }

///create feature selector handle to the complete state

export const getStudentSearchState = createFeatureSelector<StudentSearchState>('st_student_search');

//search result related selector
export const getSearchResult = createSelector(
    getStudentSearchState,
    (state:StudentSearchState)=>state.search_result
)
export const getSearchResultList = createSelector(
    getSearchResult,
    fromSearchResult.getSearchResult
)
export const getSearchResultLoading = createSelector(
    getSearchResult,
    fromSearchResult.getSearchResultLoading
)

//search input related selector
export const getSearchInput = createSelector(
    getStudentSearchState,
    (state:StudentSearchState) => state.search_input
)
export const getSearchInputCriteria = createSelector(
    getSearchInput,
    fromSearchInput.getSearchCriteria
)

export const getSearchInputQuery = createSelector(
    getSearchInput,
    fromSearchInput.getSearchQuery
)

export const getSearchInputFilter = createSelector(
    getSearchInput,
    fromSearchInput.getSearchFilter
)

//viewmode related queries/selecros
export const getSearchViewMode = createSelector(
    getStudentSearchState,
    (state:StudentSearchState) => state.search_viewmode
)

export const getViewMode = createSelector(
    getSearchViewMode,
    fromSearchViewMode.getViewMode
)
export const getVisibility = createSelector(
    getSearchViewMode,
    fromSearchViewMode.getVisibility
)
/*
export const getSearchStudentViewMode = createSelector(
    getSearchInputViewMode,
    getSearchResultViewMode,
    (inputMode,resultMode)=>{
        if((inputMode == 'min') && (resultMode == 'min'))
            return 'col-md-3';
        else
            return 'col-md-12';
    }
)
*/