import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs/Observable';

//import * as state from '../reducers/student-details.reducer';
import * as fromStudentRegister from '../reducers';

import { StudentRegisterModel } from '../model/student-register.model';
import * as studentRegisterAction from '../actions/student-register.actions';

@Component({
    selector:'student-container',
    template:` <student-register
                    [d_student_register]="s_student_register | async"
                    [d_is_loading]="s_is_loading | async"
                    (saveForm)="registerStudent($event)"
                    ></student-register>
                   
                `
})

export class StudentRegisterContainer {

    //container component to be passed to dump component properties
    s_is_loading:Observable<boolean>;
    
    s_student_register:Observable<StudentRegisterModel>;

      constructor(private _store:Store<fromStudentRegister.State>){
        this.s_student_register=this._store.select(fromStudentRegister.getStudentRegisterRecord);
        this.s_is_loading=this._store.select(fromStudentRegister.getIsLoading);
        }

    registerStudent(studentRecord:StudentRegisterModel){
        console.log('from container');
        console.log(studentRecord);
        //show loading action
        this._store.dispatch(new studentRegisterAction.EnableRegsiterStudentLoadingAction());
        //dispatch save action
        this._store.dispatch(new studentRegisterAction.RegisterStudentAction(studentRecord));
    }
  
}