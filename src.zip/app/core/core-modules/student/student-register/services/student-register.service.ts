import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';

import { StudentRegisterModel } from '../model/student-register.model';
import { AuthService } from '../../../../../root/auth-guard/auth.service';

@Injectable()
export class StudentRegisterService {
    
    //temp_query;
    constructor(private http: Http,private authService: AuthService){
        console.log('Search Service Initiated...');
        
    }
        registerStudent(studentRecord:StudentRegisterModel){

        // return this.http.get('http://localhost:4000/student/'+studentRecord)
        // .map(res => res.json());
        console.log('Http Service Call');
        let headers = new Headers ({ 'Content-Type': 'application/json' });
        //headers.append('x-access-token', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVSUQiOiJTMDAwMDkiLCJ0ZW5hbnRfaWQiOiJBQSIsInJvbGVzIjpbIlN0dWRlbnQiXSwiaWF0IjoxNTA2NDI4ODgyfQ.GwIzKK-GUgWnPWZTpMCK7EF7d5R9VF5PtgWy8QYM5Yk");
        headers.append('x-access-token', this.authService.getToken());
        let options: RequestOptions = new RequestOptions({ headers: headers });
    	var body = JSON.stringify(studentRecord);
    	console.log(body);
     return this.http.post('http://localhost:4000/api/protected/student/register', body ,options)
    .map(res =>res.json()
    );
    }
}