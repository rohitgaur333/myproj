import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromStudentRegister from './student-register.reducer';

import * as fromRoot from '../../../../../root/root-reducers/';

export interface State extends fromRoot.State{
    'st_student_register': fromStudentRegister.State
}

export const reducer = fromStudentRegister.reducer;

///create feature selector handle to the complete state

export const getStudentRegisterState = createFeatureSelector<fromStudentRegister.State>('st_student_register');

//query from the selector handle
export const getStudentRegisterRecord = createSelector(
    getStudentRegisterState,
    fromStudentRegister.getStudentRegister
);

export const getIsLoading = createSelector(
    getStudentRegisterState,
    fromStudentRegister.getStudentRegisterLoading
);
