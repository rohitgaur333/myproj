//import { Action, ActionReducer} from '@ngrx/store';

import { StudentRegisterModel } from '../model/student-register.model';

import * as StudentRegisterAction from '../actions/student-register.actions';

export interface State {
	student_register_record:StudentRegisterModel,
	is_loading:boolean
}

////////register student reducer
const draft_student :State= { student_register_record: {
                                        _id:'',
                                        sid:"",
                                        fname: "",
                                        mname:'',
                                        lname: "",
                                        gender: "",
                                        dob:"",
                                        class:"",
                                        section:"",
                                        student_mobile:null,
                                        father_name:"",
                                        father_mobile:null},
                                        is_loading:false
                                    };
                                        
//reducer function for register student data

export function reducer (state=draft_student,action:StudentRegisterAction.Interface):State{
    switch (action.type){
        case StudentRegisterAction.REGISTER_STUDENT:
        return Object.assign({},state,{student_register_record:action.payload});

        case StudentRegisterAction.REGISTER_STUDENT_SUCCESS:
        return Object.assign({},draft_student);

        case StudentRegisterAction.REGISTER_STUDENT_ERROR:
        return Object.assign({},state,{is_loading:false});

        case  StudentRegisterAction.ENABLE_REGISTER_STUDENT_LOADING:
        return Object.assign({},state,{is_loading:true});

        case StudentRegisterAction.DISABLE_REGISTER_STUDENT_LOADING:
        return Object.assign({},state,{is_loading:false});

        default:
        return state;

    }
};

export const getStudentRegister = (state:State) => state.student_register_record;
export const getStudentRegisterLoading = (state:State) => state.is_loading;
