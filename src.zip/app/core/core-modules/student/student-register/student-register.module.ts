import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule} from '@angular/router';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule } from '../../../shared-modules/modal/modal.module';

//ngrx module import
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//container import
import { StudentRegisterContainer }   from './container/student-register.container';
//component import
import { StudentRegisterComponent } from './components/student-register.component';
//routing import
import { StudentRegisterRoutes } from './student-register.routing';
//reducer import
import { reducer } from './reducers/';
//effects import
import { StudentRegisterEffects } from './effects/student-register.effect';
//sercies import 
import { StudentRegisterService } from './services/student-register.service';

@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule,
    MyDatePickerModule,
    ModalModule,
    StoreModule.forFeature('st_student_register',reducer),
    EffectsModule.forFeature([StudentRegisterEffects]),
    StudentRegisterRoutes,   
  ],
  declarations: [
    StudentRegisterContainer,
    StudentRegisterComponent,
    
    ],
  exports: [],
  providers:[StudentRegisterService]
})

export class StudentRegisterModule { }