import { ModuleWithProviders} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { StudentRegisterContainer } from './container/student-register.container';

const routes: Routes = [
   { path:'',component:StudentRegisterContainer }
];

export const StudentRegisterRoutes: ModuleWithProviders = RouterModule.forChild(routes);