import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Actions,Effect,toPayload  } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { StudentRegisterService } from '../services/student-register.service';
import * as studentRegisterAction from '../actions/student-register.actions';

import * as studentDetailsAction from '../../student-details/actions/student-details.actions';

//alert actions import
import * as alertAction from '../../../../shared-modules/alert/actions/alert.actions';

@Injectable()
export class StudentRegisterEffects {

@Effect()
registerStudent$ :Observable<Action> = this.action$
    .ofType(studentRegisterAction.REGISTER_STUDENT)
    .map(toPayload)
    .switchMap((studentRecord)=>  this.studentRegisterService.registerStudent(studentRecord)
            .mergeMap((receivedRecord)=>{
            return [
            new alertAction.AlertAppendAction({type:'SUCCESS',link_content:receivedRecord.ops[0].SID,link_url:'/core/manage/student/'+receivedRecord.ops[0].SID,alert_body:'Registration Successful'}),
            new studentRegisterAction.RegisterStudentSuccessAction(receivedRecord),
            new studentDetailsAction.GetStudentSuccessAction(receivedRecord.ops[0])
            ];
    })
            .catch((err)=>{
                    return [new alertAction.AlertAppendAction({type:'ERROR',alert_body:'Error Occured while student registration !!!'}),
                    new studentRegisterAction.RegisterStudentErrorAction()]
            }));

    constructor(private studentRegisterService:StudentRegisterService,private action$:Actions){
    }
}




/*registerStudent$ :Observable<Action> = this.action$
    .ofType(studentRegisterAction.REGISTER_STUDENT)
    .map(toPayload)
    .switchMap(studentRecord=>
          this.studentRegisterService.registerStudent(studentRecord)
            .map(receivedRecord=>
            ({type:studentRegisterAction.REGISTER_STUDENT_SUCCESS,payload:receivedRecord})
            )
            .catch(()=>Observable.of(new alertAction.AlertAppendAction({type:'ERROR',alert_body:'Error Occured while student registration !!!'}))));

    constructor(private studentRegisterService:StudentRegisterService,private action$:Actions){
    }
}
*/