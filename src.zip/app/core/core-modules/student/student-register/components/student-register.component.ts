import { ViewChild,ElementRef,Component,EventEmitter,ChangeDetectorRef,ChangeDetectionStrategy,Input,Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { IMyDpOptions,IMyDate} from 'mydatepicker';
import { Router,ActivatedRoute,Params} from '@angular/router';

import { isEqual, differenceWith,difference } from 'lodash';

import { StudentRegisterModel } from '../model/student-register.model';


@Component({
 moduleId: module.id,
  selector: 'student-register',
  templateUrl:'./student-register.component.html',
  styleUrls:['./student-register.component.css'],
  providers:[],
  changeDetection:ChangeDetectionStrategy.Default
})
export class StudentRegisterComponent  { 
   
   //local variable declaration
    studentRegisterForm:FormGroup;
    
    //popup variable
    isPopupVisible:BehaviorSubject<boolean>=new BehaviorSubject<boolean>(false);
    isPopupVisible$=this.isPopupVisible.asObservable();
    popupTitle:String='';

    //datepicker options eg format of the date
    myDatePickerOptions: IMyDpOptions = {
            dateFormat: 'dd-mm-yyyy',
            editableDateField:false};

    //input variable for date of birth field and subsequent data stream variable for datepicker input
    l_indate:BehaviorSubject<string>=new BehaviorSubject<string>('');
    l_indate$=this.l_indate.asObservable();
    

   @Input() set d_student_register (value : StudentRegisterModel){
          //for omit all error messages on record repush.
          this.studentRegisterForm.markAsUntouched();
          
          //
          this.studentRegisterForm.patchValue(value);
          this.l_indate.next(value.dob);
          console.log(this.studentRegisterForm.value);
          }
   @Input() d_is_loading:boolean;
   
   //Output event definations
   @Output() saveForm:EventEmitter<StudentRegisterModel> = new EventEmitter<StudentRegisterModel>();
     
    constructor(private formBuilder: FormBuilder,
                private ref:ChangeDetectorRef){

                this.studentRegisterForm = this.formBuilder.group({
                fname:['',Validators.required],
                mname: '',
                lname:['',Validators.required],
                gender:['',Validators.required],
                dob:['',Validators.required],
                class:[''],
                section:[''],
                student_mobile:['',Validators.required],
                father_name:['',Validators.required],
                father_mobile:['',Validators.required]
              });
      }//constructor ends

    ngOnInit() {
      console.log('insideinit');
        //initialize the form for the value to be updated.
      
     }

      //updating value on form on date update event from datepicker
  dateUpdated(dateValue){
    this.studentRegisterForm.controls['dob'].patchValue(dateValue);
    this.l_indate.next(dateValue);
    this.studentRegisterForm.controls['dob'].markAsTouched();
  }


  //styling the date form fields on basis of validation checks 
  showValidationErrorDatepickerStyle(property:string):string{
      let control:any=this.studentRegisterForm.controls[property];
        return (control.valid) ? 'datepicker-success' :'datepicker-error';
    }
    //styling the date form fields on basis of validation checks 
  showValidationErrorStyle(property:string):string{
      let control:any=this.studentRegisterForm.controls[property];
      return (control.valid) ? 'input-success' :'input-error';
    }  
  //to show error message if any on validation  check
  showValidationErrorMessage(property:string):boolean{
  let control:any=this.studentRegisterForm.controls[property];
  return !control.valid && control.touched;
}

//to save updated student record
saveStudentDetail(){
      console.log('saving form !!!');
      //console.log(this.studentRegisterForm.value);
      this.saveForm.emit(this.studentRegisterForm.value);
}  

//Reset Form Related methods
resetForm(){
  this.studentRegisterForm.reset();
  this.isPopupVisible.next(false);
  this.l_indate.next('');
  this.studentRegisterForm.controls['dob'].markAsUntouched();
}
showPopup(){
  this.popupTitle="Reseting Form";
  this.isPopupVisible.next(true);
  
}
cancelDialog(){
  console.log('cancel hit');
  this.isPopupVisible.next(false);
}

ngOnDestroy(){
  //  this.storeinstance$.unsubscribe();
  this.l_indate.unsubscribe();
  this.isPopupVisible.unsubscribe();
  }

  }
