import { Action } from '@ngrx/store';
import { StudentRegisterModel } from '../model/student-register.model';

//Action Type constants declarations
export const REGISTER_STUDENT='[StudentRegisterModel] REGISTER_STUDENT';
export const REGISTER_STUDENT_SUCCESS='[StudentRegisterModel] REGISTER_STUDENT_SUCCESS';
export const REGISTER_STUDENT_ERROR='[StudentRegisterModel] REGISTER_STUDENT_ERROR';

export const ENABLE_REGISTER_STUDENT_LOADING='[StudentRegisterModel] ENABLE_REGISTER_STUDENT_LOADING';
export const DISABLE_REGISTER_STUDENT_LOADING='[StudentRegisterModel] DISABLE_REGISTER_STUDENT_LOADING';


//interface of action
export class Interface implements Action {
  readonly type :string;
  public payload?:any;
}
//Action classes implementation

export class RegisterStudentAction implements Action {
  readonly type = REGISTER_STUDENT;
  constructor(public payload:StudentRegisterModel) {}
}

export class RegisterStudentSuccessAction implements Action {
  readonly type = REGISTER_STUDENT_SUCCESS;
  constructor(public payload:StudentRegisterModel) {}
}

export class RegisterStudentErrorAction implements Action {
  readonly type = REGISTER_STUDENT_ERROR;
  constructor() {}
}


export class EnableRegsiterStudentLoadingAction implements Action {
  readonly type = ENABLE_REGISTER_STUDENT_LOADING;
  constructor() {}
}

export class DisableRegsiterStudentLoadingAction implements Action {
  readonly type = DISABLE_REGISTER_STUDENT_LOADING;
  constructor() {}
}

