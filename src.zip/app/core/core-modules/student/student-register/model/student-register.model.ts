//interface to hold selectedstudent details information


export interface StudentRegisterModel{
	_id?:string,
	sid?:string,
	fname: string;
    mname?: string;
	lname: string;
	gender: string;
	dob :string,
	class?:string;
	section?:string;
	student_mobile:number;
	father_name:string;
	father_mobile:number;
}
