import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManageStudentContainer } from './manage-student.container';
//import { NotificationContainer } from './shared-modules/notification/container/notification.container';

const appRoutes: Routes = [
   {
    path: '',component: ManageStudentContainer,
      children:[
                { path:'student/details', loadChildren: '../../core-modules/student/student-details/student-details.module#StudentDetailsModule' },
//                { path:'student/search',  loadChildren: '../../core-modules/student/student-search/student-search.module#StudentSearchModule' },
                { path:'student/register', loadChildren: '../../core-modules/student/student-register/student-register.module#StudentRegisterModule' },
                // { path:'notify', loadChildren: './shared-modules/notification/notification.module#NotificationModule'},
             //   { path:'notify', component:NotificationContainer},
                { path:'', loadChildren: '../../shared-modules/info/info.module#InfoModule' },
            ]
    },
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const ManageStudentRoutes: ModuleWithProviders = RouterModule.forChild(appRoutes);

