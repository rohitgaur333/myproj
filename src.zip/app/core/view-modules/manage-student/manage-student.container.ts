import { Component } from '@angular/core';


@Component({
  selector: 'manage-student',
  templateUrl:'./manage-student.container.html'
})
export class ManageStudentContainer {
 
  constructor(){
 
  }
}
