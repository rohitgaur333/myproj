import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CoreContainer } from './core.container';
//import { NotificationContainer } from './shared-modules/notification/container/notification.container';

const appRoutes: Routes = [
   {
    path: '',component: CoreContainer,
      children:[
                { path:'manage',  loadChildren: './view-modules/manage-student/manage-student.module#ManageStudentModule' },
                { path:'student/details',  loadChildren: './core-modules/student/student-details/student-details.module#StudentDetailsModule' },
                { path:'student/search',   loadChildren: './core-modules/student/student-search/student-search.module#StudentSearchModule' },
                { path:'student/register', loadChildren: './core-modules/student/student-register/student-register.module#StudentRegisterModule' },
                // { path:'notify', loadChildren: './shared-modules/notification/notification.module#NotificationModule'},
             //   { path:'notify', component:NotificationContainer},
                { path:'', loadChildren: './shared-modules/info/info.module#InfoModule' },
            ]
    },
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const CoreRoutes: ModuleWithProviders = RouterModule.forChild(appRoutes);

