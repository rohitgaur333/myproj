import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './auth-guard/auth.guard';

const rootRoutes: Routes = [
  
  /*
    Route for loading core modules and further CoreModule holds feature and routing defination can be found in core.routing.ts
  */
  {
    path: 'core',
    loadChildren:  '../core/core.module#CoreModule',
    canActivate:[AuthGuard]
  },
  /*
    Route for loading Login module
  */
  {
    path: 'login',
    loadChildren:  './root-modules/login/login.module#LoginModule',
  },
   {
    path: '',
    pathMatch:'full',
    redirectTo:'login'
    //loadChildren: './root-modules/common/common.module#CustomCommonModule',
  },
  {
    path: '**',
    loadChildren: './root-modules/common/common.module#CustomCommonModule',
  }
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const RootRoutes: ModuleWithProviders = RouterModule.forRoot(rootRoutes);

