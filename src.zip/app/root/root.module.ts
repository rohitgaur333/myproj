import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//ngrx store imports
import { StoreModule,ActionReducerMap,ActionReducer } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { storeFreeze } from 'ngrx-store-freeze';

import { localStorageSync,LocalStorageConfig } from 'ngrx-store-localstorage';
//import { RouterStoreModule } from '@ngrx/router-store';
import { StoreRouterConnectingModule, routerReducer } from '@ngrx/router-store';

import { RootContainer } from './root.container';

import { RootRoutes } from './root.routing';

import { reducer } from './root-reducers/';

import { AuthGuard } from './auth-guard/auth.guard';
import { AuthService } from './auth-guard/auth.service';


//localstorage sync defination and application state hydration
export function localStorageSyncReducer(reducer: ActionReducer<any>): ActionReducer<any> {
  return localStorageSync({keys: ['st_login','st_account'],rehydrate:true})(reducer);
}
const metaReducers: Array<ActionReducer<any, any>> = [localStorageSyncReducer];
/////////////////////////////////////////////////////

@NgModule({
  declarations: [
    RootContainer,
  ],
  imports: [
    BrowserModule,
    //define store module and provide root reducer and router configuration for state management.
    StoreModule.forRoot(reducer, {metaReducers}),
    RootRoutes,
    StoreRouterConnectingModule,
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({
      maxAge: 25 //  Retains last 25 states
    })

  ],
  providers: [AuthGuard,AuthService],
  bootstrap: [RootContainer]
})
export class RootModule { }
