/*
import { Injectable } from '@angular/core';
import { JwtHelper } from '@auth0/angular-jwt';
@Injectable()
export class AuthService {
  constructor(public jwtHelper: JwtHelper) {}
  // ...
  public isAuthenticated(): boolean {
    const token = localStorage.getItem('token');
    // Check whether the token is expired and return
    // true or false
    return this.jwtHelper.isTokenExpired(token);
  }
}
*/

import { Injectable } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import { State } from '../root-reducers';
import * as fromRoot from '../root-reducers';

@Injectable()
export class AuthService {

  token:string=null;
  sub:Observable<any>;

  constructor(private _store:Store<State>) {
    this.sub=this._store.select(fromRoot.getToken);
    this.sub.subscribe(token=>{
      this.token=token;
    })
  }
  
  public isAuthenticated(): boolean {
    if(this.token)
    return true;
    else
    return false;
  }

  public getToken():string{
    return this.token;
  }
}