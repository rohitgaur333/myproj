export interface AccountModel {
	UID:string,
    login_id:string,
    tenant_id:string,
    roles:[string],
    user_name:string,
    token:string,
    module_permissions_store:ModulePermissions[]
}

export interface ModulePermissions {
    module:string,
perm:[
    {name:string,status:string}
]
}