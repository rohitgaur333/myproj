import { Action } from '@ngrx/store';
import { AccountModel } from '../root-model/root.model';

//Action Type constants declarations
export const LOAD_ACCOUNT='[AccountModel] LOAD_ACCOUNT';
export const UPDATE_TOKEN='[AccountModel] UPDATE_TOKEN';


export const LOCK_ACCOUNT='[AccountModel] LOCK_ACCOUNT';
//Action classes implementation

export class LoadAccountAction implements Action {
  readonly type = LOAD_ACCOUNT;
  constructor(public payload:AccountModel) {}
}

export class LockAccountAction implements Action {
  readonly type = LOCK_ACCOUNT;
  constructor(public payload:boolean) {}
}

export class UpdateTokenAction implements Action {
  readonly type = UPDATE_TOKEN;
  constructor(public payload:string) {}
}

export type Actions =
| LoadAccountAction
| UpdateTokenAction
| LockAccountAction;
