import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `Root Module --

  <div style="border:0px solid green">
  <a routerLink="core">
     core
     </a>
    <router-outlet></router-outlet>
    </div>
  `,
  
})
export class RootContainer {
 
  constructor(){
 
  }

}
