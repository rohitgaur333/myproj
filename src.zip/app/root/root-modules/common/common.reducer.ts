 const init={
    counter:0
}

export function commonreducer(state=init,action){
    switch(action.type)
    {
    case 'GET':
    return state;

    default:
    return state;
    }
}