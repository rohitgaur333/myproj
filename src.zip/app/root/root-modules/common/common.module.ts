import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';

//ngrx imports 
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

//components information
import { PageNotFoundComponent } from './not-found.component';
import { DummyComponent } from './dummy.component';

//import { ModalComponent } from './components/modal/modal.component';
import { AppRootRoutes } from './common.routing';

//import { reducer } from './common.reducer';
import { commonreducer } from './common.reducer';

@NgModule ({
    declarations:[
        PageNotFoundComponent,
        DummyComponent,
     //   ModalComponent
     ],
    imports:[CommonModule,FormsModule,ReactiveFormsModule,
            StoreModule.forFeature('common-root',commonreducer),
            AppRootRoutes
        ],
    exports:[
        PageNotFoundComponent,
        DummyComponent,
        
    ]

})

export class CustomCommonModule {}