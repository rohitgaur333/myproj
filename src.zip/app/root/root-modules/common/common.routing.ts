import { ModuleWithProviders} from '@angular/core';
import { Routes, RouterModule} from '@angular/router';

import { PageNotFoundComponent } from './not-found.component';
import { DummyComponent } from './dummy.component';

const appRoutes: Routes = [
  //Setting Root Routes for application routing eg "StudentContainer" or default:"PageNotFoundComponent""    
   {path: 'dummy', component: DummyComponent },
   {path: '**', component: PageNotFoundComponent },

   
   
 
 ];
//Note : Child routes will be defined in the Module Specific to the feature 

export const AppRootRoutes: ModuleWithProviders = RouterModule.forChild(appRoutes);

