import { Component ,ChangeDetectionStrategy} from '@angular/core';


@Component({

    selector:'dummy-details',
    template:`<p>Dummy Root</p>
            
                `,
    
    
})

export class DummyComponent  {

    toggle(){}

    constructor(){
       
       
    }
}
