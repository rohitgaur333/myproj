import { Component, ChangeDetectionStrategy,ChangeDetectorRef } from '@angular/core';



@Component({
  template: `<h2>Page not found Root</h2>
 

  `

 // changeDetection:ChangeDetectionStrategy.OnPush  
})
export class PageNotFoundComponent {


}