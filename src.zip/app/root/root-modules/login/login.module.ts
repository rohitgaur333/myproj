import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule} from '@angular/router';

//ngrx module import
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//Container Import
import { LoginContainer }   from './container/login.container';
//Components Import
import { LoginFormComponent } from './components/login-form/login-form.component';
import { LoginLockScreenComponent } from './components/login-lock-screen/login-lock-screen.component';
//Routing Import
import { LoginRoutes } from './login.routing';
//reducer import
import { reducer } from './reducers/';
//effects import
import { LoginEffects } from './effects/login.effect';
//sercies import 
import { LoginService } from './services/login.service';

@NgModule({
  imports:      [
    CommonModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule,
    //ModalModule,
    StoreModule.forFeature('st_login',reducer),
    EffectsModule.forFeature([LoginEffects]),
    LoginRoutes,   
  ],
  declarations: [
    LoginContainer,
    LoginFormComponent,
    LoginLockScreenComponent    
    ],
  exports: [],
  providers:[LoginService]
})

export class LoginModule { }