import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs/Observable';

//import * as state from '../reducers/login.reducer';
import * as fromLogin from '../reducers';
//Model import havning interfaces
import { AccountModel, CredentialsModel } from '../model/login.model';
//Actions Import
import * as actions from '../actions/login.actions';

//root reducer import to get account variable for lock screen such as login id etc
import * as fromRoot from '../../../root-reducers';

@Component({
    selector:'login-container',
    template:`  <div style="margin:0 auto;padding-top:10%;min-height:100vh;background-image:url('./assets/images/spacebg.jpg')">
                <login-form *ngIf="isLoginFormVisible"
                            [d_login_error]="s_login_error | async"
                            (submitCredential)="loginUser($event)">
                </login-form>
                <login-lock-screen *ngIf="isLockScreenVisible"
                                    [d_login_id]="c_login_id$ | async"
                                    [d_user_name]="c_user_name$ | async"
                                    [d_login_error]="s_login_error | async"
                                    (submitCredential)="loginUser($event)">
                                    ></login-lock-screen>
                </div>

                {{s_login_status}}

                Value: {{isLoginFormVisible | json }}
                `,
    styleUrls:['./login.container.css']
})

export class LoginContainer {

    s_login_status:Observable<string>;
    s_login_error:Observable<string>;
    isLoginFormVisible:boolean=false;
    isLockScreenVisible:boolean=false;

    c_login_id$:Observable<string>;
    c_user_name$:Observable<string>;
    

    constructor(private _store:Store<fromLogin.State>,
                private router:Router,
                private route:ActivatedRoute){
        this.s_login_status=this._store.select(fromLogin.getLoginStatus);
        this.s_login_error=this._store.select(fromLogin.getLoginError);

        //for lock screen import
        this.c_login_id$=this._store.select(fromRoot.getLoginID);
        this.c_user_name$=this._store.select(fromRoot.getUserName);

        this.s_login_status.subscribe(status=>{
            if(status=='LOGGEDIN'){
                console.log(status);
                this.router.navigate(['core']);
                //this.route.url.
            }
            else if(status=='LOCKED')
            {
                this.isLockScreenVisible=true;
                this.isLoginFormVisible=false;
            }
            else{
                this.isLoginFormVisible=true;
                this.isLockScreenVisible=false;
            }
            //this.isLoginFormVisible ?
        });
        }

    loginUser(credentials:CredentialsModel){
        console.log(credentials);
        
        this._store.dispatch(new actions.LoginAction(credentials));
    }

    ngOnDestroy(){

    }
  
}