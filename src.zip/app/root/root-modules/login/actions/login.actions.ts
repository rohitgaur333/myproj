import { Action } from '@ngrx/store';
import { CredentialsModel,LoginModel } from '../model/login.model';

//Action Type constants declarations
export const LOGIN='[LoginModel] LOGIN';
export const LOGIN_SUCCESS='[LoginModel] LOGIN_SUCCESS';
export const LOGIN_FAILURE='[LoginModel] LOGIN_FAILURE';

export const ENABLE_LOGIN_LOADING='[LoginModel] ENABLE_LOGIN_LOADING';
export const DISABLE_LOGIN_LOADING='[LoginModel] DISABLE_LOGIN_LOADING';

export const LOGIN_LOCKED='[LoginModel] LOGIN_LOCKED';
export const LOGIN_UNLOCKED='[LoginModel] LOGIN_UNLOCKED';

//Action classes implementation

export class LoginAction implements Action {
  readonly type = LOGIN;
  constructor(public payload:CredentialsModel) {}
}

export class LoginSuccessAction implements Action {
  readonly type = LOGIN_SUCCESS;
  constructor(public payload:LoginModel) {}
}

export class LoginFailureAction implements Action {
  readonly type = LOGIN_FAILURE;
  constructor(public payload:string) {}
}

export class EnableLoginLoadingAction implements Action {
  readonly type = ENABLE_LOGIN_LOADING;
  constructor(public payload?:string) {}
  
}

export class DisableLoginLoadingAction implements Action {
  readonly type = DISABLE_LOGIN_LOADING;
  constructor(public payload?:string) {}
  
}

export class LoginLockedAction implements Action {
  readonly type = LOGIN_LOCKED;
  constructor(public payload?:boolean) {}
  
}

export class LoginUnLockedAction implements Action {
  readonly type = LOGIN_UNLOCKED;
  constructor(public payload?:boolean) {}
  
}

export type Actions =
| LoginAction
| LoginSuccessAction
| LoginFailureAction
| EnableLoginLoadingAction
| DisableLoginLoadingAction
| LoginLockedAction
| LoginUnLockedAction;
