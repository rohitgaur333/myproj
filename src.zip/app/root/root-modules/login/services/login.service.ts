import {Injectable} from '@angular/core';
import {Http,RequestOptions,Headers} from '@angular/http'
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';

import { CredentialsModel } from '../model/login.model';

@Injectable()
export class LoginService {
    
    //temp_query;
    constructor(private http: Http){
        console.log('Login Service Initiated...');
        
    }
        login(credentials:CredentialsModel){
        // return this.http.get('http://localhost:4000/student/'+studentRecord)
        // .map(res => res.json());
         console.log('Http Service Call');
        let headers = new Headers ({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
    	var body = JSON.stringify(credentials);
    	console.log(body);
     return this.http.post('http://localhost:4000/api/public/authenticate', body ,options)
    .map(res =>res.json());
    }
}