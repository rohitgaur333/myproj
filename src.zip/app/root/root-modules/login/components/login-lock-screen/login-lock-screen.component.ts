import { ViewChild,ElementRef,Component,EventEmitter,ChangeDetectorRef,ChangeDetectionStrategy,Input,Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { IMyDpOptions,IMyDate} from 'mydatepicker';
import { Router,ActivatedRoute,Params} from '@angular/router';

//import { isEqual, differenceWith,difference } from 'lodash';

import { CredentialsModel } from '../../model/login.model';


@Component({
 moduleId: module.id,
  selector: 'login-lock-screen',
  templateUrl:'./login-lock-screen.component.html',
  styleUrls:['./login-lock-screen.component.css'],
  providers:[],
  changeDetection:ChangeDetectionStrategy.Default
})
export class LoginLockScreenComponent  { 
  loginForm:FormGroup;
  
    @Input() d_login_id:string;
    @Input() d_user_name:string;
    @Input() d_login_error:string;
    
    @Output() submitCredential:EventEmitter<CredentialsModel>=new EventEmitter<CredentialsModel>();
  
    constructor(private fb:FormBuilder){
      this.loginForm=this.fb.group({
        login_id:['' ,Validators.required],
        password:['',Validators.required]
      });
    }

    ngOnInit(){
      this.loginForm.patchValue({login_id:this.d_login_id});
    }
  
    submitForm(){
      console.log(this.loginForm.value);
      this.submitCredential.emit(this.loginForm.value);
    }

  }
