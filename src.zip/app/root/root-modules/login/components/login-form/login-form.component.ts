import { ViewChild,ElementRef,Component,EventEmitter,ChangeDetectorRef,ChangeDetectionStrategy,Input,Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { IMyDpOptions,IMyDate} from 'mydatepicker';
import { Router,ActivatedRoute,Params} from '@angular/router';

//import { isEqual, differenceWith,difference } from 'lodash';

import { CredentialsModel } from '../../model/login.model';


@Component({
 moduleId: module.id,
  selector: 'login-form',
  templateUrl:'./login-form.component.html',
  styleUrls:['./login-form.component.css'],
  providers:[],
  changeDetection:ChangeDetectionStrategy.Default
})
export class LoginFormComponent  { 
   
  loginForm:FormGroup;

  @Input() d_login_error:string;
  
  @Output() submitCredential:EventEmitter<CredentialsModel>=new EventEmitter<CredentialsModel>();

  constructor(private fb:FormBuilder){
    this.loginForm=this.fb.group({
      login_id:['',Validators.required],
      password:['',Validators.required]
    });
  }

  submitForm(){
    console.log(this.loginForm.value);
    this.submitCredential.emit(this.loginForm.value);
  }

  showValidationErrorStyle(property:string):string{
    let control:any=this.loginForm.controls[property];
    return (control.valid) ? 'input-success' :'input-error';
  }  
  //to show error message if any on validation  check
  showValidationErrorMessage(property:string):boolean{
  let control:any=this.loginForm.controls[property];
  return !control.valid && control.touched;
  }

  }
