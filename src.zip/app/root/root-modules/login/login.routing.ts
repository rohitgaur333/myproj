import { ModuleWithProviders} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginContainer } from './container/login.container';

/*
setting up login default route to LoginContainer
*/

const routes: Routes = [
   { path:'',component:LoginContainer }
];

export const LoginRoutes: ModuleWithProviders = RouterModule.forChild(routes);