import { Action, ActionReducer} from '@ngrx/store';

import { LoginModel, CredentialsModel } from '../model/login.model';

import * as loginAction from '../actions/login.actions';

export interface State {
    user:LoginModel,
    login_status:string,
    login_error:string,
	is_loading:boolean
}

////////register student reducer
const loginInitialState :State= { 
                                user:{login_id:'AAS00001'},
                                login_status:null,
                                login_error:null,
                                is_loading:false
                                    };
                                        
//reducer function for login operations

export function reducer (state=loginInitialState,action:loginAction.Actions):State{
    switch (action.type){
        case loginAction.LOGIN:
        return Object.assign({},state,{login_error:null,is_loading:true});

        case loginAction.LOGIN_SUCCESS:
        return Object.assign({},state,{ 
                                        user:{login_id:action.payload},
                                        login_status:'LOGGEDIN',
                                        login_error:null,
                                        is_loading:false}
            );
        case loginAction.LOGIN_LOCKED:
        return Object.assign({},state,{ 
                                            login_status:'LOCKED',
                                            is_loading:false
                                        });
        case loginAction.LOGIN_FAILURE:
        return Object.assign({},state,{ 
                                        login_error:action.payload,
                                        is_loading:false
                                    });
        /*
                                    case  loginAction.LOG:
        return Object.assign({},state,{is_loading:true});

        case StudentRegisterAction.DISABLE_REGISTER_STUDENT_LOADING:
        return Object.assign({},state,{is_loading:false});
*/
        default:
        return state;

    }
};

//export const getAccount = (state:State) => state.account;
export const getLoginUser = (state:State) => state.user;
export const getLoginStatus = (state:State) => state.login_status;
export const getLoginError = (state:State) => state.login_error;
export const getIsLoading = (state:State) => state.is_loading;
