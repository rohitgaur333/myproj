import { createSelector, createFeatureSelector } from '@ngrx/store';

import * as fromLogin from './login.reducer';

import * as fromRoot from '../../../root-reducers/';

export interface State extends fromRoot.State{
    'st_login': fromLogin.State
}

export const reducer = fromLogin.reducer;

///create feature selector handle to the complete state

export const getLoginState = createFeatureSelector<fromLogin.State>('st_login');

//query from the selector handle

///////////////////////////////////////////////////////////

export const getLoginUser = createSelector(
    getLoginState,
    fromLogin.getLoginUser
);

export const getUserLoginID = createSelector(
    getLoginUser,
    (user)=>{
        return user.login_id
    }
)
///////////////////////////////////////////////////////////

export const getLoginStatus = createSelector(
    getLoginState,
    fromLogin.getLoginStatus
);

export const getLoginError = createSelector(
    getLoginState,
    fromLogin.getLoginError
);

export const getIsLoading = createSelector(
    getLoginState,
    fromLogin.getIsLoading
);
