//interface to hold login and related information


export interface AccountModel{
	login_id:string,
	UID:string,
	tenant_id:string,
	roles:[string],
	token:string,
	module_permissions:[
						{
							module:string,
						perm:[
							{name:string,status:string}
						]
						}
					]
}

export interface LoginModel{
	login_id:string
}

export interface CredentialsModel{
	login_id:string,
	password:string
}

/*
account: {        
                                        UID:null,
                                        login_id:null,
                                        tenant_id:null,
                                        roles:[null],
                                        token:null,
                                        module_permissions:[
                                                            {
                                                                module:null,
                                                            perm:[
                                                                {name:null,status:null}
                                                            ]
                                                            }
                                                        ]
									  }
									  
									  */