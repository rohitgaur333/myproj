// counter.ts
import { Action } from '@ngrx/store';

export interface State {
	count:number
}

const initialState:State = {
	count:10
}

export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const RESET = 'RESET';

export function reducer (state :State= initialState, action: Action) {
	switch (action.type) {
		case INCREMENT:
			return Object.assign({},{count: state.count+1 });

		case DECREMENT:
			return Object.assign({},{count: state.count-1 });

		case RESET:
			return Object.assign({},{count: 0});

		default:
			return state;
	}
}