import {
  ActionReducerMap,
  createSelector,
  createFeatureSelector,
  ActionReducer,
} from '@ngrx/store';

import * as fromRouter from '@ngrx/router-store';
import { AccountModel } from '../root-model/root.model';
import * as fromRoot from './root.reducer';
import * as fromAccount from './account.reducer';

export interface State {
    root:fromRoot.State,
    st_account:AccountModel
    //routerReducer:fromRouter.RouterReducerState
}
export const reducer :ActionReducerMap<State> = {
    root : fromRoot.reducer,
    st_account: fromAccount.reducer
    //routerReducer:fromRouter.routerReducer
}
//query from the selector handle
///////////////////////////////////////////////////////////
export const  getAccountState = createFeatureSelector<AccountModel>('st_account');

//query from the selector handle
///////////////////////////////////////////////////////////

export const getUID = createSelector(
    getAccountState,
    fromAccount.getUID
)

export const getLoginID = createSelector(
    getAccountState,
    fromAccount.getLoginID
)

export const getTenantID = createSelector(
    getAccountState,
    fromAccount.getTenantID
)

export const getRoles = createSelector(
    getAccountState,
    fromAccount.getRoles
)

export const getToken = createSelector(
    getAccountState,
    fromAccount.getToken
)

export const getUserName = createSelector(
    getAccountState,
    fromAccount.getUserName
)

export const getModulePermissionStore = createSelector(
    getAccountState,
    fromAccount.getModulePermissionStore
)

export const getAccountProfile = createSelector(
    getAccountState,
    (accountState)=>{ return {
    login_id:accountState.login_id,
    user_name:accountState.user_name,
    image_url:null
    }
}
)