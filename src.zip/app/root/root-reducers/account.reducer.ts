// counter.ts
import { Action } from '@ngrx/store';

import * as accountAction from '../root-actions/root.actions';
import { AccountModel, ModulePermissions } from '../root-model/root.model';

const initialAccountState:AccountModel = {
	UID:null,
    login_id:null,
    tenant_id:null,
    roles:[null],
	user_name:null,
    token:null,
    module_permissions_store:[]
}

export function reducer (state :AccountModel= initialAccountState, action: accountAction.Actions) {
	switch (action.type) {
		case accountAction.LOAD_ACCOUNT:
			return Object.assign({},state,action.payload);

		case accountAction.UPDATE_TOKEN:
			return Object.assign({},state,{token:action.payload});

		case accountAction.LOCK_ACCOUNT:
		return Object.assign({},state,{token:null});

		default:
			return state;
	}
}


export const getUID = (state:AccountModel) =>state.UID;
export const getLoginID = (state:AccountModel) =>state.login_id;
export const getTenantID = (state:AccountModel) =>state.tenant_id;
export const getRoles = (state:AccountModel) =>state.roles;
export const getUserName = (state:AccountModel) =>state.user_name;
export const getToken = (state:AccountModel) =>state.token;
export const getModulePermissionStore = (state:AccountModel) =>state.module_permissions_store;