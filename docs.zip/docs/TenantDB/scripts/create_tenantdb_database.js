/*
master database creation
*/

var MongoClient = require('mongodb').MongoClient;
/*
Update the db_url with following syntax to create tenant db

var db_url = "mongodb://<hostname/IP>:<port>/<dbname>";
*/
var db_url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(db_url, function(err, db) {
  if (err) throw err;
  console.log("Tenant Database created!");
  db.close();
});