var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var default_roles = [
{
  role_name:'Admin',
  module_set:[
  {
    module:"StudentDetails",
    perm:[
            {"name":"default","status":true},
            {"name":"view","status":true},
            {"name":"edit","status":true}
        ]
  },
  {
  module:"StudentRegister",
  perm:[
          {"name":"default","status":true}
          ]
  },
  {
  module:"StudentSearch",
  perm:[
          {"name":"default","status":true},
          {"name":"only_assigned_class","status":true},
          {"name":"all_students","status":true}
          ]
  }
  ]
},
{
  role_name:'Teacher',
  module_set:[
  {
    module:"StudentDetails",
    perm:[
            {"name":"default","status":true},
            {"name":"view","status":true},
            {"name":"edit","status":false}
        ]
  },
  {
  module:"StudentRegister",
  perm:[
          {"name":"default","status":false}
          ]
  },
  {
  module:"StudentSearch",
  perm:[
          {"name":"default","status":true},
          {"name":"only_assigned_class","status":true},
          {"name":"all_students","status":true}
          ]
  }
  ]
}
];
  db.collection("roles").insertMany(default_roles, function(err, res) {
    if (err) throw err;
    console.log(res.insertedCount+" Modules Inserted");
    db.close();
  });
});
