/*
sequence collections creation
*/

var MongoClient = require('mongodb').MongoClient;
var db_url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(db_url, function(err, db) {
  if (err) throw err;
  db.createCollection("sequence_uid", function(err, res) {
    if (err) throw err;
    console.log("UID Sequence Collection created!");
    db.close();
  });
});
