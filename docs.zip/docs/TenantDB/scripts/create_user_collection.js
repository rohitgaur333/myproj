/*
sequence collections creation
*/

var MongoClient = require('mongodb').MongoClient;
var db_url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(db_url, function(err, db) {
  if (err) throw err;
  db.createCollection("user", function(err, res) {
    if (err) throw err;
    console.log("User Collection created!");
    db.close();
  });
});



