var MongoClient = require('mongodb').MongoClient;
var db_url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(db_url, function(err, db) {
  if (err) throw err;

  var sequence_records = [{
      _id: "student",
      prefix:"S",
      seq: 00000
   },
   {
      _id: "mentor",
      prefix:"M",
      seq: 00000
   },
   {
      _id: "parent",
      prefix:"P",
      seq: 00000
   }
];

  db.collection("sequence_uid").insertMany(sequence_records, function(err, res) {
    if (err) throw err;
    console.log(res.ops.length+" Sequence Registered");
    //console.log(res);
    db.close();
  });
});

