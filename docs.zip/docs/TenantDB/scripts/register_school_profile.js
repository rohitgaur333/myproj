var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/tenantdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var school_profile = {
    school_name:"ABC Organization",
    logo_url:"http://www.google.com",
    image_url:"http://www.google.com",
    short_name:"ABC",
  };
  db.collection("school_profile").insertOne(school_profile, function(err, res) {
    if (err) throw err;
    console.log(" Profile Inserted");
    db.close();
  });
});
