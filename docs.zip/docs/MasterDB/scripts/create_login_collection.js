/*
auth collections creation
*/

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/masterdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  db.createCollection("login", function(err, res) {
    if (err) throw err;
    console.log("Login Collection created!");
    db.close();
  });
});

