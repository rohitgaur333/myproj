var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/masterdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var module_permissions = [
{
module:"StudentDetails",
perm:[
        {"name":"default"},
        {"name":"view"},
        {"name":"edit"}
    ]
},
{
module:"StudentRegister",
perm:[
        {"name":"default"}
        ]
},
{
module:"StudentSearch",
perm:[
        {"name":"default"},
        {"name":"only_assigned_class"},
        {"name":"all_students"}
        ]
}
];
  db.collection("all_module_permissions").insertMany(module_permissions, function(err, res) {
    if (err) throw err;
    console.log(res.insertedCount+" Modules Inserted");
    db.close();
  });
});
