var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/masterdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var tenant_record = {
    tenant_id:'AD',
    name:"Test Organization",
    url:"mongodb://localhost:27017/tenantdb",
    admin:"admin",
    password:"password"
};
  db.collection("tenants").insertOne(tenant_record, function(err, res) {
    if (err) throw err;
    console.log("1 tenant inserted");
    console.log()
    db.close();
  });
});

/*
Dummy Data to be inserted

{
    tenant_id:'AA',
    name:"ABC Organization",
    url:"mongodb://localhost:27017/AA",
    admin:"admin",
    password:"password"
}

{
    tenant_id:'AB',
    name:"XYZ Organization",
    url:"mongodb://localhost:27017/schooldb",
    admin:"admin",
    password:"password"
}

{
    tenant_id:'AD',
    name:"First Organization",
    url:"mongodb://localhost:27018/test",
    admin:"admin",
    password:"password"
}



*/