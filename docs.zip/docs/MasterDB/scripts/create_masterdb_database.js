/*
master database creation
*/

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/masterdb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  console.log("MasterDatabase created!");
  db.close();
});